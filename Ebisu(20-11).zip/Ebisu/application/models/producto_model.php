<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Producto_model extends CI_Model {


	public function listarproducto()
	{
		
		$this->db->select('*');
		$this->db->from('producto');
		$this->db->where('estado',$estado=1);
		return $this->db->get();
	}
	public function listarproductogus()
	{
		$this->db->select('*');
		$this->db->from('megusta');
		//$this->db->group_by ('nombre');
		//$this->db->order_by ('1 DESC');
		return $this->db->get();
	}
	public function listarproductonogus()
	{
		$this->db->select('*');
		$this->db->from('nomegusta');
		//$this->db->group_by('nombre');
		//$this->db->order_by('1 DESC');
		return $this->db->get();
	}
	public function listarproductouno()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=1);
		return $this->db->get();
	}
	public function listarproductodos()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=2);
		return $this->db->get();
	}

	public function listardeseos()
	{
		$this->db->select('*');
		$this->db->from('listadeseos');
		//$this->db->where('nombre'$this->session->userdata('nombre'));
		$this->db->where ('nombreUsuario',$this->session->userdata('nombre'));
		return $this->db->get();
	}

	public function listarproductotres()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=3);
		return $this->db->get();
	}

	public function listarproductocuatro()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=4);
		return $this->db->get();
	}

	public function listarproductocinco()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=5);
		return $this->db->get();
	}

	public function listarproductoseis()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=6);
		return $this->db->get();
	}
	public function listarproductosiete()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=7);
		return $this->db->get();
	}
	public function listarproductoocho()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=8);
		return $this->db->get();
	}
	public function listarproductonueve()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=9);
		return $this->db->get();
	}
	public function listarproductodiez()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=10);
		return $this->db->get();
	}
	public function listarproductoonce()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=11);
		return $this->db->get();
	}
	public function listarproductodoce()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=12);
		return $this->db->get();
	}
	
	
	public function recuperarusuario($IdProducto)
	{
		$this->db->select('IdUsuario');
		$this->db->from('producto');
		$this->db->where('IdProducto',$IdProducto);
        return $this->db->get();

	}


	public function reportarusuario($IdUsuario)
	{
		
		$this->db->set('reportado',$reportado=1);
		$this->db->where('IdUsuario',$IdUsuario);
		$this->db->update('usuario');
		
     }

    

	public function modificarproducto($IdProducto,$data)

	{
		$this->db->where('IdProducto',$IdProducto);
		$this->db->update('producto',$data);
	}
	public function modiproducto($pro)

	{
		$this->db->where('IdProducto');
		$this->db->update('registroproducto',$pro);
	}
	public function comprarproducto($IdProducto,$data)

	{
		$this->db->select('*');
		$this->db->from('producto AS P');
		$this->db->join('usuario as U');
		$this->db->on('P.IdUsuario=U.IdUsuario');
		$this->db->where('P.IdProducto',$IdProducto);
		$this->db->groupby('P.nombre');



//		$this->db->where('IdProducto',$IdProducto);
//		$this->db->update('producto',$data);
	}
	public function agregarproducto($data)

	{
		
		$this->db->insert('producto',$data);
	}
	public function registrarproducto($pro)
	{
		
		$this->db->insert('registroproducto',$pro);
	}
	public function activarproducto($IdProducto)
	{
		
		$this->db->set('estado',$estado=0);
		$this->db->where('IdProducto',$IdProducto);
		$this->db->update('producto');
	}
	public function lista($pro)
	{
		
		$this->db->insert('listadeseos',$pro);
	}
	
	public function recuperarproducto($IdProducto)
	{
		$this->db->select('*');
		$this->db->from('producto');
		$this->db->where('IdProducto',$IdProducto);
        return $this->db->get();

	}
	public function recuperarnombrevendedor($IdProducto)
	{
		$this->db->select('nombrevendedor');
		$this->db->from('producto');
		$this->db->where('IdProducto',$IdProducto);
        return $this->db->get();
	}
	public function reportar($data)

	{
		$this->db->insert('usuariosreportados',$data);
	}
	public function megusta($data)

	{
		$this->db->insert('megusta',$data);
	}
	public function nomegusta($data)

	{
		$this->db->insert('nomegusta',$data);
	}

	

	


	
	
}

