<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usuario extends CI_Controller {

	

	public function index()
	{ 
		$data['msg']=$this->uri->segment(3);
		if ($this->session->userdata('nombre'))
		{

			redirect('usuarios/panel','refresh');
		}
		else
		{
		//$listausurio=$this->usuario_model->listarusurio();
		//$data['usuarios']=$listausurio;
		$this->load->view('login',$data);
		}

		
	}
	public function validarusuario()
	{
		$nombre=$_POST['nombre'];
		$password=md5($_POST['password']);
		$telefono=$_POST['telefono'];
		
		
		$consulta=$this->usuario_model->validar($nombre,$password,$telefono);
		
		if ($consulta->num_rows()>0)//si existe el usuario 
		{
			foreach ($consulta->result() as $row)
			{
				
				$this->session->set_userdata('IdUsuario',$row->IdUsuario);
				$this->session->set_userdata('nombre',$row->nombre);
				$this->session->set_userdata('telefono',$row->telefono);
               // $this->session->set_userdata('tipo',$row->tipo);
                

			}redirect('usuario/panel','refresh');
			
		}
		else
			{
				redirect('usuario/index/1','refresh');
			}
		

		
	}
	public function panel()
	{
		if ($this->session->userdata('nombre'))
		{

			$this->load->view('inicio');

		}
		else
		{
		//$listausurio=$this->usuario_model->listarusurio();
		//$data['usuarios']=$listausurio;
			redirect('usuario/index/2','refresh');

		}

	}
	
	 public function logout()
	{
		$this->session->sess_destroy();
		redirect('usuario/index/3','refresh');
	}
	
	public function listausurio()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuario']=$listausurio;
		$this->load->view('lista_usuario',$data);
	}
	public function funciona()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuarios']=$listausurio;
		$this->load->view('comoFunciona',$data);
	}
	
	public function productosno()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuarios']=$listausurio;
		$this->load->view('ProductosNo',$data);
	}
	public function condicion()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuarios']=$listausurio;
		$this->load->view('condicionUso',$data);
	}

	public function modificar()
	{
		$IdUsuario=$_POST['IdUsuario'];
		$data['infousuario']=$this->usuario_model->recuperarusuario($IdUsuario);
		$this->load->view('modificarUsuario',$data);
	}
	public function modificardb()
	{
		
		$IdUsuario=$_POST['IdUsuario'];
		$data['nombre']=$_POST['nombre'];
		$data['primerApellido']=$_POST['primerApellido'];
		$data['segundoApellido']=$_POST['segundoApellido'];
		$data['correo']=$_POST['correo'];
		$data['password']=$_POST['password'];
		$data['telefono']=$_POST['telefono'];
		$data['idCiudad']=$_POST['idCiudad'];
		$data['fechaModificacion']=$_POST['fechaModificacion'];
		$this->usuario_model->modificarusuario($IdUsuario,$data);
				//cargar la 
		redirect('usuario/index','refresh');
	}

	public function modificarp()
	{
		
		$IdProducto=$_POST['IdProducto'];
		
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		
		$this->load->view('contacto',$data);

	}

	public function productomodificardb()
	{
		$IdProducto=$_POST['IdProducto'];
		$data['codigo']=$_POST['codigo'];
		$data['nombre']=$_POST['nombre'];
		$data['descripcion']=$_POST['descripcion'];
		$data['IdCategoria']=$_POST['IdCategoria'];
		$data['precioBase']=$_POST['precioBase'];
		$data['stock']=$_POST['stock'];
		$IdImagen=$_FILES['IdImagen']['name'];
		$archivo=$_FILES['IdImagen']['tmp_name'];
		$ruta="img";
		$ruta=$ruta."/".$IdImagen;
		move_uploaded_file($archivo, $ruta);
		
		$data['fechaModificacion']=$_POST['fechaModificacion'];
		$this->producto_model->modificarproducto($IdProducto,$data);
	    redirect('usuario/listaproducto','refresh');
	}
	public function agregar()
	{
		$this->load->view('signin');
	}

	public function agregardb()
	{
		$data['nombre']=$_POST['nombre'];
		$data['primerApellido']=$_POST['primerApellido'];
		$data['segundoApellido']=$_POST['segundoApellido'];
		$data['correo']=$_POST['correo'];
		$data['password']=md5($_POST['password']);
		$data['telefono']=$_POST['telefono'];
		$pr['idUsuario']=$_POST['telefono'];
		$data['estado']=1;
		$data['fechaCreacion']=$_POST['fechaCreacion'];

		
		$this->usuario_model->agregarusuario($data);
		$this->usuario_model->registrarproducto($pr);
		redirect('usuario/index','refresh');
	}
	

	public function produc()
	{
		if ($this->session->userdata('nombre'))
		{
			$this->load->view('categorias');
		}
		else
		{
		
			redirect('usuario/index/2','refresh');
		}

		
	}
	
	public function agregarproducto()
	{
		if ($this->session->userdata('nombre'))
		{
		

			$this->load->view('registrar_producto');

		}
		else
		{
		
			redirect('usuario/index/2','refresh');

		}

		
	}
	
	public function agregarproductodb()
	{
		if ($this->session->userdata('nombre'))
		{

		$data['codigo']=$_POST['codigo'];
		$data['nombre']=$_POST['nombre'];
		$data['descripcion']=$_POST['descripcion'];
		$data['categoria']=$_POST['categoria'];
		$data['precioBase']=$_POST['precioBase'];
		//$data['stock']=$_POST['stock'];
		$data['estado']=1;
		$pro['idProducto']=$_POST['codigo'];

		//$pro['idUsuario']=$_POST['telefono'];
		$pro['descripcion']=$_POST['descripcion'];
		$pro['fechaRegistro']=$_POST['fechaCreacion'];
		$data['fechaCreacion']=$_POST['fechaCreacion'];
		//$data['ruta']=$_POST['ruta'];
		if($_FILES['ruta']['type']=='image/png')
		{
			$data['codigo']=$_POST['codigo'];
			copy($_FILES['ruta']['tmp_name'],'img/'.$data['codigo'].'.png');
			$data['ruta']=$data['codigo'].".png";

			$this->producto_model->agregarproducto($data);
			$this->producto_model->registrarproducto($pro);
		
		redirect('usuario/panel','refresh');

		}
		
		}
		else
		{
		
			redirect('usuario/index/2','refresh');
		}
		
	}

	public function listaproducto()
	{
		
		$listaproducto=$this->producto_model->listarproducto();
		$data['producto']=$listaproducto;
		
		$this->load->view('ordenarProducto',$data);
		
	}
	public function listaproductouno()
	{
		$listaproducto=$this->producto_model->listarproductouno();
		$data['producto']=$listaproducto;
		$this->load->view('categorias',$data);
	}
	public function listaproductodos()
	{
		$listaproducto=$this->producto_model->listarproductodos();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasdos',$data);
	}
	public function listaproductotres()
	{
		$listaproducto=$this->producto_model->listarproductotres();
		$data['producto']=$listaproducto;
		$this->load->view('categoriastres',$data);
	}
	public function listaproductocuatro()
	{
		$listaproducto=$this->producto_model->listarproductocuatro();
		$data['producto']=$listaproducto;
		$this->load->view('categoriascuatro',$data);
	}
	public function listaproductocinco()
	{
		$listaproducto=$this->producto_model->listarproductocinco();
		$data['producto']=$listaproducto;
		$this->load->view('categoriascinco',$data);
	}
	public function listaproductoseis()
	{               
		$listaproducto=$this->producto_model->listarproductoseis();
		$data['producto']=$listaproducto;
		$listausuario=$this->usuario_model->listarusurio();
		$data['usuario']=$listausuario;
		$this->load->view('categoriasseis',$data);
	}
	
	public function listaproductosiete()
	{
		$listaproducto=$this->producto_model->listarproductosiete();
		$data['producto']=$listaproducto;
		$this->load->view('categoriassiete',$data);
	}
	public function listaproductoocho()
	{
		$listaproducto=$this->producto_model->listarproductoocho();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasocho',$data);
	}
	public function listaproductonueve()
	{
		$listaproducto=$this->producto_model->listarproductonueve();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasnueve',$data);
	}
	public function listaproductodiez()
	{
		$listaproducto=$this->producto_model->listarproductodiez();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasdiez',$data);
	}
	public function listaproductoonce()
	{
		$listaproducto=$this->producto_model->listarproductoonce();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasonce',$data);
	}
	public function listaproductodoce()
	{
		$listaproducto=$this->producto_model->listarproductodoce();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasdoce',$data);
	}
	
	
	public function compraproducto()
	{
		
		$IdProducto=$_POST['idProducto'];
		//$IdUsuario=$_POST['idUsuario'];
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		//$data['infousuario']=$this->usuario_model->recuperarusuario($IdUsuario);
		$listausuario=$this->usuario_model->listarusurio();
		$data['usuario']=$listausuario;
		$this->load->view('contacto',$data);


	}


	public function listadeseos()
	{
		$IdProducto=$_POST['idProducto'];
		$data['codigo']=$_POST['codigo'];
		$data['fechaCreacion']=$_POST['fechaCreacion'];
		$pro['IdProducto']=$_POST['codigo'];
		$pro['estado']=1;
		$pro['fechaCreacion']=$_POST['fechaCreacion'];
		
		$this->producto_model->lista($pro);
		$this->load->view('deseos',$data);
	}
	public function habilitarusuario()
	{
		
		$IdUsuario=$_POST['IdUsuario'];
		$this->usuario_model->ver($IdUsuario);
		redirect('usuario/index','refresh');

	}
	public function habilitarproducto()
	{
		
		$IdProducto=$_POST['IdProducto'];
		$this->producto_model->activarproducto($IdProducto);
		redirect('usuario/listaproducto','refresh');

	}
	
	
	
	



}

 


