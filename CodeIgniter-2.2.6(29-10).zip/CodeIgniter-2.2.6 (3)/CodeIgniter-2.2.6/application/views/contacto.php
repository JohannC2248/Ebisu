<!DOCTYPE html>
<html lang="en">
<head>
<title>Resale_v2 a Classified ads Category Flat Bootstrap Responsive Website Template | Single :: w3layouts</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="<?php echo base_url(); ?>public/web/css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
<!-- js -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url(); ?>public/web/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/bootstrap-select.js"></script>
<script>
  $(document).ready(function () {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker({
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<!-- language-select -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.leanModal.min.js"></script>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.utils.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.lcd.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.languagefilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.regionfilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.core.js"></script>
<script>
			$( document ).ready( function() {
				$( '.uls-trigger' ).uls( {
					onSelect : function( language ) {
						var languageName = $.uls.data.getAutonym( language );
						$( '.uls-trigger' ).text( languageName );
					},
					quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
				} );
			} );
		</script>
<!-- //language-select -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/flexslider.css" media="screen" /><!-- flexslider css -->
</head>
<body>
	
	<div class="agiletopbar">
			<div class="wthreenavigation">
				<div class="menu-wrap">
				<nav class="menu">
					<div class="icon-list">
						<a href="<?php echo base_url(); ?>/index.php/usuario/listaproducto"><i class="fa fa-fw fa-mobile"></i><span>LISTA PRODUCTOS</span></a>
						<a href="<?php echo base_url(); ?>/index.php/usuario/listausurio"><i class="fa fa-fw fa-laptop"></i><span>LISTA USUARIOS</span></a>
						
					</div>
				</nav>
				<button class="close-button" id="close-button">Close Menu</button>
			</div>
			<button class="menu-button" id="open-button"> </button>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- //Navigation -->
	<!-- header -->
	<header>
		<div class="w3ls-header"><!--header-one--> 
			
			<div class="w3ls-header-right">
				<ul>

					<li class="dropdown head-dpdn">
						<h1><a href="" aria-expanded="false"><i aria-hidden="true">HOLA  <?php echo $this->session->userdata('nombre'); ?></a></h1> 
						
					</li>
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>index.php/usuario/logout" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i>CERRAR SESSION</a>
					</li>
					
			
					
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-question-circle" aria-hidden="true"></i> Ayuda</a>
					</li>
					
					
				</ul>
			</div>
			
			<div class="clearfix"> 
				<ul>
					<li>
					
    
 		   
					</li>
				</ul>
			</div> 
		</div>
		<div class="container">
			<div class="agile-its-header">
				<div class="logo">
					
					<h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><img src="<?php echo base_url(); ?>public/web/images/logo3.png" alt="Image" class="block-center img-rounded" width="150"><span>Ebisu</span>-SAFE SALE FROM HOME </a> </h1>

				</div>
				<div class="agileits_search">
					
				<a  class="post-w3layouts-ad btn btn-purple" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodos">Nuestro Producto</a>
				

				<a class="post-w3layouts-ad" href="<?php echo base_url(); ?>/index.php/usuario/agregarproducto">Registrar Producto</a>
				</div>	
				<div class="clearfix"></div>
			</div>
		</div>
	</header>
	
	<!-- //breadcrumbs -->


	<?php
         foreach ($infoproducto->result() as $row) {

         	
         
         $atributos=array('class'=>'form-horizontal','role'=>'form','id'=>'miForm');
         
         echo form_open_multipart('usuario/productomodificardb',$atributos);
         ?>
           
        

	<!--single-page-->






	<div class="single-page main-grid-border">
		<div class="container">
			<div class="product-desc">
				<div class="col-md-7 product-view">
					
					<div class="flexslider">
						<ul class="slides">
							<li data-thumb="images/ss1.jpg">
								<img src="<?php echo base_url(); ?>public/web/images/ss1.jpg" />
							</li>
							
						</ul>
					</div>
					<!-- FlexSlider -->
					  <script defer src="<?php echo base_url(); ?>public/web/js/jquery.flexslider.js"></script>

						<script>
					// Can also be used with $(document).ready()
					$(window).load(function() {
					  $('.flexslider').flexslider({
						animation: "slide",
						controlNav: "thumbnails"
					  });
					});
					</script>
					<!-- //FlexSlider -->
					<div class="product-details">
						<h4><span class="w3layouts-agileinfo">Nombre </span> : <a href="<?php echo base_url(); ?>public/web/#"><?php echo $row->nombre; ?></a><div class="clearfix"></div></h4>
						<h4><span class="w3layouts-agileinfo">Descripcion</span> :<p><?php echo $row->descripcion; ?></p><div class="clearfix"></div></h4>
					
					</div>
				</div>
				<div class="col-md-5 product-details-grid">
					<div class="item-price">
						<div class="product-price">
							<p class="p-price">Precio</p>
							<h3 class="rate"><?php echo $row->precioBase; ?></h3>
							<div class="clearfix"></div>
						</div>
						<div class="condition">
							<p class="p-price">Stok</p>
							<h4><?php echo $row->stock; ?></h4>
							<div class="clearfix"></div>
						</div>
						<div class="itemtype">
							<p class="p-price">Codigo Producto</p>
							<h4><?php echo $row->codigo; ?></h4>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="interested text-center">
						<h4>Interesado en el Producto?<small> Contacta al vendedor!</small></h4>
						<p><i class="glyphicon glyphicon-earphone"></i><?php echo $this->session->userdata('telefono'); ?></p><br>

						<button type="submit" class="bt btn-danger">
						<li class="ma0 pa0 w-grid-4 w-grid-8-l w-grid-12-2x ph4 pv3"><a href="" class="router-link-active w-100 link color-inherit hover-indigo6 flex flex-column justify-center items-center"><span class="relative mb3"><svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="thumbs-up" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-thumbs-up fa-w-16 fa-fw fa-2x"><path fill="currentColor" d="M466.27 286.69C475.04 271.84 480 256 480 236.85c0-44.015-37.218-85.58-85.82-85.58H357.7c4.92-12.81 8.85-28.13 8.85-46.54C366.55 31.936 328.86 0 271.28 0c-61.607 0-58.093 94.933-71.76 108.6-22.747 22.747-49.615 66.447-68.76 83.4H32c-17.673 0-32 14.327-32 32v240c0 17.673 14.327 32 32 32h64c14.893 0 27.408-10.174 30.978-23.95 44.509 1.001 75.06 39.94 177.802 39.94 7.22 0 15.22.01 22.22.01 77.117 0 111.986-39.423 112.94-95.33 13.319-18.425 20.299-43.122 17.34-66.99 9.854-18.452 13.664-40.343 8.99-62.99zm-61.75 53.83c12.56 21.13 1.26 49.41-13.94 57.57 7.7 48.78-17.608 65.9-53.12 65.9h-37.82c-71.639 0-118.029-37.82-171.64-37.82V240h10.92c28.36 0 67.98-70.89 94.54-97.46 28.36-28.36 18.91-75.63 37.82-94.54 47.27 0 47.27 32.98 47.27 56.73 0 39.17-28.36 56.72-28.36 94.54h103.99c21.11 0 37.73 18.91 37.82 37.82.09 18.9-12.82 37.81-22.27 37.81 13.489 14.555 16.371 45.236-5.21 65.62zM88 432c0 13.255-10.745 24-24 24s-24-10.745-24-24 10.745-24 24-24 24 10.745 24 24z" class=""></path></svg></span></a></li>
						&nbsp;Me Gusta &nbsp;1</button>

					</div>
						
				</div>
			<div class="clearfix"></div>
			</div>
		</div>
	</div>
	 <?php echo form_close();
         }
         
          ?>
	<!--//single-page-->
	<!--footer section start-->		
		<footer>
			<div class="w3-agileits-footer-top">
				<div class="container">
					<div class="wthree-foo-grids">
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Quienes somos</h4>
							<p>Para la solución al problema realizaremos una página web donde la gente pueda ofrecer sus productos y servicios y así poder llegar a mucha gente desde la comodidad de sus hogares, pensamos en eso ya que la mayoría de gente sin estudios superiores optan por el comercio de productos o servicios y así poder ganar dinero</p>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Ayuda</h4>
							<ul>
								<li><a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Como Funciona </a></li>						
								
								<li><a href="<?php echo base_url(); ?>index.php/usuario/productosno"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Productos no Validos</a></li>
								
								
								
							</ul>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Informacion</h4>
							<ul>
									
								<li><a href="<?php echo base_url(); ?>index.php/usuario/condicion"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Condiciones de Uso</a></li>
								
							</ul>
						</div>
						
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="agileits-footer-bottom text-center">
			<div class="container">
				<div class="logo">
					<h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><span>Ebisu</span>-SAFE SALE FROM HOME</a></h1> 
				</div>
				<div class="copyrights">
					<p> © 2020. Creado por Team Ebisu |   <a href="<?php echo base_url(); ?>public/web/http://w3layouts.com/"> Cochabamba - Bolivia </a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->
</body>
		<!-- Navigation-JavaScript -->
			<script src="<?php echo base_url(); ?>public/web/js/classie.js"></script>
			<script src="<?php echo base_url(); ?>public/web/js/main.js"></script>
		<!-- //Navigation-JavaScript -->
		<!-- here stars scrolling icon -->
			<script type="text/javascript">
				$(document).ready(function() {
					/*
						var defaults = {
						containerID: 'toTop', // fading element id
						containerHoverID: 'toTopHover', // fading element hover id
						scrollSpeed: 1200,
						easingType: 'linear' 
						};
					*/
										
					$().UItoTop({ easingType: 'easeOutQuart' });
										
					});
			</script>
			<!-- start-smoth-scrolling -->
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/move-top.js"></script>
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
			</script>
			<!-- start-smoth-scrolling -->
		<!-- //here ends scrolling icon -->
</html>