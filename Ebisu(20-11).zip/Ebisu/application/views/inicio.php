<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Ebisu SAFE SALE FROM HOME </title>
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="<?php echo base_url(); ?>public/web/css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/flexslider.css" type="text/css" media="screen" /><!-- flexslider-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="<?php echo base_url(); ?>public/web/js/jquery-3.3.1.js"></script>

<!-- Popper JS -->
<script src="<?php echo base_url(); ?>public/web/js/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="<?php echo base_url(); ?>public/web/js/bootstrap.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
</head>
<body>	
		<!-- Navigation -->
		<div class="agiletopbar">
			<div class="wthreenavigation">
				<div class="menu-wrap">
				<nav class="menu">
					<div class="icon-list">
						<a href="<?php echo base_url(); ?>/index.php/usuario/listaproducto"><i class="fa fa-fw fa-mobile"></i><span>LISTA PRODUCTOS</span></a>
						<a href="<?php echo base_url(); ?>/index.php/usuario/listausurio"><i class="fa fa-fw fa-laptop"></i><span>LISTA USUARIOS</span></a>
						<a href="<?php echo base_url(); ?>/index.php/usuario/listarusurioreportado"><i class="fa fa-fw fa-laptop"></i><span>LISTA USUARIOS REPORTADOS</span></a>
						
					</div>
				</nav>
				<button class="close-button" id="close-button">Close Menu</button>
			</div>
			<button class="menu-button" id="open-button"> </button>
			</div>
			<div class="clearfix"></div>
		</div>
		<!-- //Navigation -->
	<!-- header -->
	<header>
		<div class="w3ls-header"><!--header-one--> 
			
			<div class="w3ls-header-right">
				<ul>

					<li class="dropdown head-dpdn">
						<h1><a href="" aria-expanded="false"><i aria-hidden="true">HOLA  <?php echo $this->session->userdata('nombre'); ?></a></h1> 


						
					</li>
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>index.php/usuario/logout" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i>CERRAR SESSION</a>
					</li>
					
			
					
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-question-circle" aria-hidden="true"></i> Ayuda</a>
					</li>
					
					
				</ul>
			</div>
			
			<div class="clearfix"> 
				<ul>
					<li>
					
    
 		   
					</li>
				</ul>
			</div> 
		</div>
		<div class="container">
			<div class="agile-its-header">
				<div class="logo">
					
					<h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><img src="<?php echo base_url(); ?>public/web/images/logo3.png" alt="Image" class="block-center img-rounded" width="150"><span>Ebisu</span>-SAFE SALE FROM HOME </a> </h1>

					<a  class="post-w3layouts-ad btn btn-info" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodos">Nuestros Productos</a>

					<a class="post-w3layouts-ad btn btn-primary" href="<?php echo base_url(); ?>/index.php/usuario/agregarproducto">Registrar Producto</a>

					<a  class="post-w3layouts-ad btn btn-success" href="<?php echo base_url(); ?>/index.php/usuario/listaproductogusta">Productos mas Gustados</a>

					<a  class="post-w3layouts-ad btn btn-danger" href="<?php echo base_url(); ?>/index.php/usuario/listaproductonogusta">Productos menos Gustado</a>

				</div>
				
			</div>
		</div><br>
	</header>
	<!-- //header -->
	<!-- Slider -->
		<div class="slider"><ul>
			<li></li>
		</ul>
			<ul class="rslides" id="slider">
				<li>
					
				</li>
				<li>
					
				</li>
				<li>
					<div class="w3ls-slide-text">
						
					</div>
				</li>
				<li>
					
				</li>
				<li>
					
				</li>
			</ul>
		</div>
		<!-- //Slider -->
		<!-- content-starts-here -->
		<div class="main-content">
			<div class="w3-categories">
				<h3>Examinar Categorias</h3>
				<div class="container">
					<div class="col-md-3">
						<div class="focus-grid w3layouts-boder1">
							<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductouno#parentVerticalTab1">
								<div class="focus-border">
									<div class="focus-layout">
										<div class="focus-image"><i class="fa fa-home"></i></div>
										<h4 class="clrchg">CASA Y JARDIN</h4>
									</div>
								</div>
							</a>
						</div>
					</div>
					<div class="col-md-3">
						<div class="focus-grid w3layouts-boder2">	
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodos#parentVerticalTab2">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-female"></i></div>
									<h4 class="clrchg"> ROPA Y ACCESORIOS</h4>
								</div>
							</div>
						</a>
					</div>
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder3">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductotres#parentVerticalTab3">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-laptop"></i></div>
									<h4 class="clrchg"> ELECTRONICOS</h4>
								</div>
							</div>
						</a>
					</div>	
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder4">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductocuatro#parentVerticalTab4">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-bicycle"></i></div>
									<h4 class="clrchg">BICICLETAS</h4>
								</div>
							</div>
						</a>
					</div>	
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder5">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductocinco#parentVerticalTab5">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-rocket"></i></div>
									<h4 class="clrchg">JUGUETES</h4>
								</div>
							</div>
						</a>
					</div>
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder6">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductoseis#parentVerticalTab6">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-file"></i></div>
									<h4 class="clrchg">CLASIFICADOS</h4>
								</div>
							</div>
						</a>
					</div>	
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder7">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductosiete#parentVerticalTab7">
							
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-book"></i></div>
									<h4 class="clrchg">LIBROS PASAPORTES Y DEPORTES</h4>
								</div>
							</div>
						</a>
					</div>	
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder8">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductoocho#parentVerticalTab8">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-music"></i></div>
									<h4 class="clrchg">INSTRUMENTOS</h4>
								</div>
							</div>
						</a>
					</div>	
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder9">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductonueve#parentVerticalTab9">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-gamepad"></i></div>
									<h4 class="clrchg">ENTRETENIMINETO</h4>
								</div>
							</div>
						</a>
					</div>	
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder10">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodeiz#parentVerticalTab10">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-briefcase"></i></div>
									<h4 class="clrchg">SERVICIOS</h4>
								</div>
							</div>
						</a>
					</div>
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder11">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductoonce#parentVerticalTab11">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-building-o"></i></div>
									<h4 class="clrchg">TRABAJO</h4>
								</div>
							</div>
						</a>
					</div>
					</div>
					<div class="col-md-3">
					<div class="focus-grid w3layouts-boder12">
						<a class="btn-8" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodoce#parentVerticalTab12">
							<div class="focus-border">
								<div class="focus-layout">
									<div class="focus-image"><i class="fa fa-bed"></i></div>
									<h4 class="clrchg">MUEBLES</h4>
								</div>
							</div>
						</a>
					</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<!-- most-popular-ads -->
			
			<!-- most-popular-ads -->									
			
			<!--partners-->
			
			<!-- //mobile app -->
		</div>
		<!--footer section start-->		
		<footer>
			<div class="w3-agileits-footer-top">
				<div class="container">
					<div class="wthree-foo-grids">
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Quienes somos</h4>
							<p>Para la solución al problema realizaremos una página web donde la gente pueda ofrecer sus productos y servicios y así poder llegar a mucha gente desde la comodidad de sus hogares, pensamos en eso ya que la mayoría de gente sin estudios superiores optan por el comercio de productos o servicios y así poder ganar dinero</p>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Ayuda</h4>
							<ul>
								<li><a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Como Funciona </a></li>						
								
								<li><a href="<?php echo base_url(); ?>index.php/usuario/productosno"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Productos no Validos</a></li>
								
								
								
							</ul>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Informacion</h4>
							<ul>
									
								<li><a href="<?php echo base_url(); ?>index.php/usuario/condicion"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Condiciones de Uso</a></li>

								
									<li><h3>Contactanos</h3>
	<a href="https://mail.google.com/mail/u/0/#inbox?compose=CllgCJlHmqfghfsRTTVqwdNsSlNJqjMvftfsFMfnpdWQhfvmrFdtrCqkWGnCNcnZrMhWTjxjTML">carrito0918@gmail.com</a></li>
								

								
							</ul>
						</div>
						
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="agileits-footer-bottom text-center">
			<div class="container">
				<div class="logo">
					<h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><span>Ebisu</span>-SAFE SALE FROM HOME</a></h1> 
				</div>
				<div class="copyrights">
					<p> © 2020. Creado por Team Ebisu |   <a href="<?php echo base_url(); ?>public/web/http://w3layouts.com/"> Cochabamba - Bolivia </a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->
		<!-- Navigation-Js-->
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/main.js"></script>
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/classie.js"></script>
		<!-- //Navigation-Js-->
		<!-- js -->
		<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.min.js"></script>
		<!-- js -->
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="<?php echo base_url(); ?>public/web/js/bootstrap.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/bootstrap-select.js"></script>
		<script>
		  $(document).ready(function () {
			var mySelect = $('#first-disabled2');

			$('#special').on('click', function () {
			  mySelect.find('option:selected').prop('disabled', true);
			  mySelect.selectpicker('refresh');
			});

			$('#special2').on('click', function () {
			  mySelect.find('option:disabled').prop('disabled', false);
			  mySelect.selectpicker('refresh');
			});

			$('#basic2').selectpicker({
			  liveSearch: true,
			  maxOptions: 1
			});
		  });
		</script>
		<!-- language-select -->
		<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.leanModal.min.js"></script>
		<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.grid.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.lcd.css" rel="stylesheet"/>
		<!-- Source -->
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.utils.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.lcd.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.languagefilter.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.regionfilter.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.core.js"></script>
		<script>
					$( document ).ready( function() {
						$( '.uls-trigger' ).uls( {
							onSelect : function( language ) {
								var languageName = $.uls.data.getAutonym( language );
								$( '.uls-trigger' ).text( languageName );
							},
							quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
						} );
					} );
				</script>
		<!-- //language-select -->
		<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.flexisel.js"></script><!-- flexisel-js -->	
					<script type="text/javascript">
						 $(window).load(function() {
							$("#flexiselDemo3").flexisel({
								visibleItems:1,
								animationSpeed: 1000,
								autoPlay: true,
								autoPlaySpeed: 5000,    		
								pauseOnHover: true,
								enableResponsiveBreakpoints: true,
								responsiveBreakpoints: { 
									portrait: { 
										changePoint:480,
										visibleItems:1
									}, 
									landscape: { 
										changePoint:640,
										visibleItems:1
									},
									tablet: { 
										changePoint:768,
										visibleItems:1
									}
								}
							});
							
						});
					   </script>
		<!-- Slider-JavaScript -->
			<script src="<?php echo base_url(); ?>public/web/js/responsiveslides.min.js"></script>	
			 <script>
			$(function () {	
			  $("#slider").responsiveSlides({
				auto: true,
				pager: false,
				nav: true,
				speed: 500,
				maxwidth: 800,
				namespace: "large-btns"
			  });

			});
		  </script>
		<!-- //Slider-JavaScript -->
		<!-- here stars scrolling icon -->
			<script type="text/javascript">
				$(document).ready(function() {
					/*
						var defaults = {
						containerID: 'toTop', // fading element id
						containerHoverID: 'toTopHover', // fading element hover id
						scrollSpeed: 1200,
						easingType: 'linear' 
						};
					*/
										
					$().UItoTop({ easingType: 'easeOutQuart' });
										
					});
			</script>
			<!-- start-smoth-scrolling -->
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/move-top.js"></script>
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
			</script>
			<!-- start-smoth-scrolling -->
		<!-- //here ends scrolling icon -->
</body>		
</html>