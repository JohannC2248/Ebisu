<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Registroproducto_model extends CI_Model {


	public function listarproducto()
	{
		$this->db->select('*');
		$this->db->from('producto');
		$this->db->where('estado',$estado=1);

		return $this->db->get();
	}
	public function recuperarproducto($IdProducto)
	{
		$this->db->select('*');
		$this->db->from('producto');
		$this->db->where('IdProducto',$IdProducto);
        return $this->db->get();
	}
	public function modificarproducto($IdProducto,$data)

	{
		$this->db->where('IdProducto',$IdProducto);
		$this->db->update('producto',$data);
	}
	public function agregarproducto($data)

	{
		
		$this->db->insert('producto',$data,$ruta);
	}
	public function activarproducto($IdProducto)
	{
		
		$this->db->set('estado',$estado=0);
		$this->db->where('IdProducto',$IdProducto);
		$this->db->update('producto');
	}
	

	

	


	
	
}

