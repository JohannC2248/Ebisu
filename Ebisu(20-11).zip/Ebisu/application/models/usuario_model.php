<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usuario_model extends CI_Model {

	public function validar($nombre,$password)
	{
		$this->db->select('*');
		$this->db->from('usuario');
		$this->db->where('nombre',$nombre);
		$this->db->where('password',$password);
		//$this->db->where('estado',$estado);
		
		
		return $this->db->get();
	}
	
	public function agregarusu($pr)
	{
		
		$this->db->select('IdUsuario');
		$this->db->from('usuario');
		$this->db->where('nombre',$nombre);
        $this->db->insert('registroproducto',$pr);
	}
	public function listarusurio()
	{
		$this->db-> select(' *');
		$this->db->from('usuario');
		return $this->db->get();
        
        
	}

	public function listarusurioreportado()
	{
		$this->db-> select('*');
		$this->db->from('usuariosreportados');
		
		return $this->db->get();
        
	}

	public function recuperarusuario($IdUsuario)
	{
		$this->db->select('*');
		$this->db->from('usuario');
		$this->db->where('IdUsuario',$IdUsuario);
        return $this->db->get();
	}
	public function modificarusuario($IdUsuario,$data)
	{
		$this->db->where('IdUsuario',$IdUsuario);
		$this->db->update('usuario',$data);
	}
	public function agregarusuario($data)
	{
		
		$this->db->insert('usuario',$data);
	}
	public function registrarproducto($pr)
					
	{
		
		$this->db->insert('registroproducto',$pr);
	}
	public function ver($IdUsuario)
	{
		
		$this->db->set('estado',$activo=0);
		$this->db->where('IdUsuario',$IdUsuario);
		$this->db->update('usuario');
	}
	

	
	


	
	
}

