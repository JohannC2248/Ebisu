<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usuario extends CI_Controller {

	

	public function index()
	{ 
		$data['msg']=$this->uri->segment(3);
		if ($this->session->userdata('nombre'))
		{

			redirect('usuarios/panel','refresh');
		}
		else
		{
		//$listausurio=$this->usuario_model->listarusurio();
		//$data['usuarios']=$listausurio;
		$this->load->view('login',$data);
		}

		
	}
	public function validarusuario()
	{
		$nombre=$_POST['nombre'];
		$password=md5($_POST['password']);
		//$estado=$_POST['estado'];
		//$telefono=$_POST['telefono'];
		
		
		$consulta=$this->usuario_model->validar($nombre,$password);
		
		if ($consulta->num_rows()>0)//si existe el usuario 
		{
			foreach ($consulta->result() as $row)
			{
				
				$this->session->set_userdata('IdUsuario',$row->IdUsuario);
				$this->session->set_userdata('nombre',$row->nombre);
				//$this->session->set_userdata('telefono',$row->telefono);
               // $this->session->set_userdata('tipo',$row->tipo);
                

			}redirect('usuario/panel','refresh');
			
		}
		
		else
			{
				redirect('usuario/index/1','refresh');
			}
		

		
	}
	public function panel()
	{
		if ($this->session->userdata('nombre'))
		{

			$this->load->view('inicio');

		}
		else
		{
		//$listausurio=$this->usuario_model->listarusurio();
		//$data['usuarios']=$listausurio;
			redirect('usuario/index/2','refresh');

		}

	}
	
	 public function logout()
	{
		$this->session->sess_destroy();
		redirect('usuario/index/3','refresh');
	}
	
	public function listausurio()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuario']=$listausurio;
		$this->load->view('lista_usuario',$data);
	}

	

	public function listarusurioreportado()
	{
		$listausuriorepo=$this->usuario_model->listarusurioreportado();
		$data['usuario']=$listausuriorepo;
		$this->load->view('lista_usuarioreportado',$data);
	}
	public function funciona()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuarios']=$listausurio;
		$this->load->view('comoFunciona',$data);
	}
	
	public function productosno()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuarios']=$listausurio;
		$this->load->view('ProductosNo',$data);
	}
	public function condicion()
	{
		$listausurio=$this->usuario_model->listarusurio();
		$data['usuarios']=$listausurio;
		$this->load->view('condicionUso',$data);
	}

	public function modificar()
	{
		$IdUsuario= $this->session->userdata('IdUsuario');
		$data['infousuario']=$this->usuario_model->recuperarusuario($IdUsuario);
		$this->load->view('modificarUsuario',$data);
	}


	public function modificardb()
	{
		
		$IdUsuario=$_POST['IdUsuario'];
		$data['nombre']=$_POST['nombre'];
		$data['primerApellido']=$_POST['primerApellido'];
		$data['segundoApellido']=$_POST['segundoApellido'];
		$data['correo']=$_POST['correo'];
		$data['password']=md5($_POST['password']);
		$data['telefono']=$_POST['telefono'];
		$data['fechaModificacion']=$_POST['fechaModificacion'];
		$this->usuario_model->modificarusuario($IdUsuario,$data);
				//cargar la 
		redirect('usuario/listausurio','refresh');
	}



	public function modificarp()
	{
		
		$IdProducto=$_POST['IdProducto'];
		
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		
		$this->load->view('contacto',$data);

	}
	public function modificarpro()
	{
		
		$IdProducto=$_POST['IdProducto'];
		
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		
		$this->load->view('modificarproducto',$data);

	}

	
	public function productomodificardb()
	{
		$IdProducto=$_POST['IdProducto'];
		$data['codigo']=$_POST['codigo'];
		$data['nombre']=$_POST['nombre'];
		$data['descripcion']=$_POST['descripcion'];
		$data['categoria']=$_POST['categoria'];
		$data['precioBase']=$_POST['precioBase'];
		$data['telefonoVendedor']=$_POST['telefonoVendedor'];
		$data['inicio']=$_POST['inicio'];
		$data['fin']=$_POST['fin'];
		$data['fechaModificacion']=$_POST['fechaModificacion'];
		$pro['idProducto']=$_POST['codigo'];
		$pro['fechaModificacion']=$_POST['fechaModificacion'];
		$pro['idUsuario']= $this->session->userdata('IdUsuario');
		$pro['descripcion']=$_POST['descripcion'];
		$this->producto_model->modificarproducto($IdProducto,$data);
		$this->producto_model->modiproducto($pro);
	    redirect('usuario/listaproducto','refresh');
	}

	public function reportardb()
	{
		//$IdProducto=$_POST['IdProducto'];
		$data['nombreR']=$this->session->userdata('nombre');
		$data['nombreRD']=$_POST['nombrevendedor'];
		$data['descripcion']=$_POST['descripcion'];
		$data['fechaCreacion']=$_POST['fechaCreacion'];
		$data['tiporepor']=$_POST['tiporepor'];
		$this->producto_model->reportar($data);
	    redirect('usuario/listaproducto','refresh');
	} 

	public function megustadb()
	{
		$data['IdProducto']=$_POST['IdProducto'];
		$data['nombre']=$_POST['nombre'];
		$data['precioBase']=$_POST['precioBase'];
		$data['descripcion']=$_POST['descripcion'];
		
		$this->producto_model->megusta($data);
	    redirect('usuario/listaproductogusta','refresh');
	}
	public function nomegustadb()
	{
		$data['IdProducto']=$_POST['IdProducto'];
		$data['nombre']=$_POST['nombre'];
		$data['precioBase']=$_POST['precioBase'];
		$data['descripcion']=$_POST['descripcion'];
		
		$this->producto_model->nomegusta($data);
	    redirect('usuario/listaproductonogusta','refresh');
	}
	public function agregar()
	{
		$this->load->view('signin');
	}

	public function agregardb()
	{
		$data['nombre']=$_POST['nombre'];
		$data['primerApellido']=$_POST['primerApellido'];
		$data['segundoApellido']=$_POST['segundoApellido'];
		$data['correo']=$_POST['correo'];
		$data['password']=md5($_POST['password']);
		$data['telefono']=$_POST['telefono'];
		//$pr['idUsuario']=$_POST['telefono'];
		$data['estado']=1;
		$data['fechaCreacion']=$_POST['fechaCreacion'];

		
		$this->usuario_model->agregarusuario($data);
		//$this->usuario_model->registrarproducto($pr);
		redirect('usuario/index','refresh');
	}

	
	

	public function produc()
	{
		if ($this->session->userdata('nombre'))
		{
			$this->load->view('categorias');
		}
		else
		{
		
			redirect('usuario/index/2','refresh');
		}

		
	}
	
	public function agregarproducto()
	{
		if ($this->session->userdata('nombre'))
		{
		

			$this->load->view('registrar_producto');

		}
		else
		{
		
			redirect('usuario/index/2','refresh');

		}

		
	}
	
	public function agregarproductodb()
	{
		if ($this->session->userdata('nombre'))
		{

		$data['codigo']=$_POST['codigo'];
		$data['nombre']=$_POST['nombre'];
		$data['descripcion']=$_POST['descripcion'];
		$data['categoria']=$_POST['categoria'];
		$data['precioBase']=$_POST['precioBase'];
		$data['fechaCreacion']=$_POST['fechaCreacion'];
		$data['estado']=1;
		$data['inicio']=$_POST['inicio'];
		$data['fin']=$_POST['fin'];
		$data['nombrevendedor']=$this->session->userdata('nombre');
		$data['telefonoVendedor']=$_POST['telefonoVendedor'];
		$pro['idProducto']=$_POST['codigo'];
		$pro['fechaCreacion']=$_POST['fechaCreacion'];
		$pro['idUsuario']= $this->session->userdata('IdUsuario');
		$pro['descripcion']=$_POST['descripcion'];
		
		$data['ruta']=$_POST['ruta'];
		if($_FILES['ruta']['type']=='image/png')
		{
			//$data['codigo']=$_POST['codigo'];
			copy($_FILES['ruta']['tmp_name'],'img/'.$data['codigo'].'.png');
			$data['ruta']=$data['codigo'].".png";

			$this->producto_model->agregarproducto($data);
			$this->producto_model->registrarproducto($pro);
		
		redirect('usuario/panel','refresh');

		}
		
		}
		else
		{
		
			redirect('usuario/index/2','refresh');
		}
		
	}

	
	public function listaproductogusta()
	{
		
		$listaproducto=$this->producto_model->listarproductogus();
		$data['producto']=$listaproducto;
		
		$this->load->view('ProductosGustados',$data);
		
	}

	public function listaproductonogusta()
	{
		
		$listaproducto=$this->producto_model->listarproductonogus();
		$data['producto']=$listaproducto;
		
		$this->load->view('productonomegusta',$data);
		
	}
	public function listadeseosver()
	{
		$listaproducto=$this->producto_model->listardeseos();
		$data['producto']=$listaproducto;
		$this->load->view('deseos',$data);
		
	}
	public function listaproducto()
	{
		
		$listaproducto=$this->producto_model->listarproducto();
		$data['producto']=$listaproducto;
		
		$this->load->view('ordenarProducto',$data);
		
	}
	public function listaproductouno()
	{
		$listaproducto=$this->producto_model->listarproductouno();
		$data['producto']=$listaproducto;
		$this->load->view('categorias',$data);
	}
	public function listaproductodos()
	{
		$listaproducto=$this->producto_model->listarproductodos();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasdos',$data);
	}
	
	public function listaproductotres()
	{
		$listaproducto=$this->producto_model->listarproductotres();
		$data['producto']=$listaproducto;
		$this->load->view('categoriastres',$data);
	}
	public function listaproductocuatro()
	{
		$listaproducto=$this->producto_model->listarproductocuatro();
		$data['producto']=$listaproducto;
		$this->load->view('categoriascuatro',$data);
	}
	public function listaproductocinco()
	{
		$listaproducto=$this->producto_model->listarproductocinco();
		$data['producto']=$listaproducto;
		$this->load->view('categoriascinco',$data);
	}
	public function listaproductoseis()
	{               
		$listaproducto=$this->producto_model->listarproductoseis();
		$data['producto']=$listaproducto;
		$listausuario=$this->usuario_model->listarusurio();
		$data['usuario']=$listausuario;
		$this->load->view('categoriasseis',$data);
	}
	
	public function listaproductosiete()
	{
		$listaproducto=$this->producto_model->listarproductosiete();
		$data['producto']=$listaproducto;
		$this->load->view('categoriassiete',$data);
	}
	public function listaproductoocho()
	{
		$listaproducto=$this->producto_model->listarproductoocho();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasocho',$data);
	}
	public function listaproductonueve()
	{
		$listaproducto=$this->producto_model->listarproductonueve();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasnueve',$data);
	}
	public function listaproductodiez()
	{
		$listaproducto=$this->producto_model->listarproductodiez();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasdiez',$data);
	}
	public function listaproductoonce()
	{
		$listaproducto=$this->producto_model->listarproductoonce();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasonce',$data);
	}
	public function listaproductodoce()
	{
		$listaproducto=$this->producto_model->listarproductodoce();
		$data['producto']=$listaproducto;
		$this->load->view('categoriasdoce',$data);
	}
	
	
	public function compraproducto()
	{
		
		$IdProducto=$_POST['idProducto'];
		//$IdUsuario=$_POST['idUsuario'];
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		//$data['infousuario']=$this->usuario_model->recuperarusuario($IdUsuario);
		//$listausuario=$this->usuario_model->listarusurio();
		//$data['usuario']=$listausuario;
		$this->load->view('contacto',$data);
	}

	public function megusta()
	{
		
		
		
		$IdProducto=$_POST['idProducto'];
		
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		;
		$this->load->view('megusta',$data);
		
		
		
	}
	public function nomegusta()
	{
		
		
		
		$IdProducto=$_POST['idProducto'];
		
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		
		$this->load->view('nomegusta',$data);
		
		
		
	}
	public function reportarusuario()
	{
		$IdProducto=$_POST['idProducto'];
		$data['infoproducto']=$this->producto_model->recuperarproducto($IdProducto);
		$this->load->view('reporte',$data);
	}

	public function listadeseos()
	{
		$IdProducto=$_POST['idProducto'];
		//$data['codigo']=$_POST['codigo'];
		$data['fechaCreacion']=$_POST['fechaCreacion'];
		$data['precioBase']=$_POST['precioBase'];
		$data['nombre']=$_POST['nombre'];
		$data['IdProducto']=$_POST['codigo'];
		$data['nombreUsuario']= $this->session->userdata('nombre');
		
		$pro['fechaCreacion']=$_POST['fechaCreacion'];
		
		$this->producto_model->lista($data);
		redirect('usuario/listadeseosver','refresh');
		//redirect('usuario/listadeseos','refresh');

	}
	public function habilitarusuario()
	{
		
		$IdUsuario=$_POST['IdUsuario'];
		$this->usuario_model->ver($IdUsuario);
		$this->load->view('lista_usuario',$data);

	}
	public function habilitarproducto()
	{
		
		$IdProducto=$_POST['IdProducto'];
		$this->producto_model->activarproducto($IdProducto);
		redirect('usuario/listaproducto','refresh');

	}
	
	
	
	



}

 


