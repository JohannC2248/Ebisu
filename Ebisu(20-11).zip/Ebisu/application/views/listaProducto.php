<div class="contanier">
	<div class="row">
		<div class=" col-md-12">

			

			<h1>Lista  de productos</h1>
			<table class="table">
				<thead>
					<tr>No.</tr>
					<tr>Codigo</tr>
					<tr>Nombre</tr>
					<tr>Descripcion</tr>
					<tr>Categoria</tr>
					<tr>Precio</tr>
					<tr>Stock</tr>
					<tr>Imagen</tr>
					<tr>Fecha de Creacion</tr>
				</thead>
				<tbody>
					<?php
					$indice=1;
					foreach ($producto->result() as $row)
					{
						?>
						<tr>
						<td><?php echo $indice;?> </td>
						<td><?php echo $row->codigo;?> </td>
						<td><?php echo $row->nombre;?> </td>
						<td><?php echo $row->descripcion;?> </td>
						<td><?php echo $row->IdCategoria;?> </td>
						<td><?php echo $row->precioBase;?> </td>
						<td><?php echo $row->stock;?> </td>
						<td><?php echo $row->IdImagen?> </td>
						<td><?php echo $row->fechaCreacion;?> </td>
						<td>
							<?php echo form_open_multipart('usuario/modificarProducto');?>
							<input type="text" name="idProducto" value="<?php echo $row->IdProducto; ?>">
							<button type="submit" class="bt btn-success">MODIFICAR</button>
							<?php echo form_close(); ?>
						</td>
						

						<td>
							<?php echo form_open_multipart('usuario/habilitarproducto');?>
							<input type="hidden" name="IdProducto" value="<?php echo $row->IdProducto; ?>">
							<button type="submit" class="bt btn-success">ACTIVO</button>
							<?php echo form_close(); ?>
						</td>
	                   </tr>
	                 <?php
				$indice++;
					}
					?>


				</tbody>
				
			</table>
		</div>
	</div>
</div>





