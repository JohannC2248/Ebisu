<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Ebisu SAFE SALE FROM HOME a Classified ads Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="<?php echo base_url(); ?>public/web/css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/flexslider.css" type="text/css" media="screen" /><!-- flexslider-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
</head>
<body>	
		<!-- Navigation -->
		<header>
      <div class="w3ls-header"><!--header-one--> 
         
         <div class="w3ls-header-right">
            <ul>

               <li class="dropdown head-dpdn">
                  <h1><a href="" aria-expanded="false"><i aria-hidden="true">HOLA  <?php echo $this->session->userdata('nombre'); ?></a></h1> 
                  
               </li>
               <li class="dropdown head-dpdn">
                  <a href="<?php echo base_url(); ?>index.php/usuario/logout" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i>CERRAR SESSION</a>
               </li>
               
         
               
               <li class="dropdown head-dpdn">
                  <a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-question-circle" aria-hidden="true"></i> Ayuda</a>
               </li>
               
               
            </ul>
         </div>
         
         <div class="clearfix"> 
            <ul>
               <li>
               
    
         
               </li>
            </ul>
         </div> 
      </div>
       <div class="container">
         <div class="agile-its-header">
            <div class="logo">
               
               <h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><img src="<?php echo base_url(); ?>public/web/images/logo3.png" alt="Image" class="block-center img-rounded" width="150"><span>Ebisu</span>-SAFE SALE FROM HOME </a> </h1>

               <a  class="post-w3layouts-ad btn btn-info" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodos">Nuestros Productos</a>

               <a class="post-w3layouts-ad btn btn-primary" href="<?php echo base_url(); ?>/index.php/usuario/agregarproducto">Registrar Producto</a>

               <a  class="post-w3layouts-ad btn btn-success" href="<?php echo base_url(); ?>/index.php/usuario/listaproductogusta">Productos mas Gustados</a>

               <a  class="post-w3layouts-ad btn btn-danger" href="<?php echo base_url(); ?>/index.php/usuario/listaproductonogusta">Productos menos Gustado</a>

            </div>
            
         </div>
      </div><br><div class="container">
         
      </div>
   </header>

				
				<div class="agileinfo-ads-display col-md-9">
					<div class="wrapper">					
					<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
					  <ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
						
						
						<li role="presentation">
						  <a href="<?php echo base_url(); ?>public/web/#samsa" role="tab" id="samsa-tab" data-toggle="tab" aria-controls="samsa">
							<span class="text">LISTA DE USUARIO REPORTADOS</span>
						  </a>
						</li>
					  </ul>
					  <div id="myTabContent" class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
						   <div>
												<div id="container">
								
								<div class="sort">
								 
									 </div>
								<div class="clearfix"></div>
							
						</div>
							</div>
						</div>
						<div class="row">
		
			
			<table class="table table-bordered" id="dataTable" cellspacing="3">
				<thead>
					<th>No.</th>
					<th>Nombre del repotado</th>
					<th>Nombre al que reporta</th>
					<th>Tipo de Reporte</th>
					<th>Descripcion</th>
					
					
				</thead>
				<tbody>
					<?php
					$indice=1;
					foreach ($usuario->result() as $row)
					{
						?>
						<tr>
						<td><?php echo $indice;?> </td>
						<td><?php echo $row->nombreR;?> </td>
						<td><?php echo $row->nombreRD;?> </td>
						<td><?php echo $row->tiporepor;?> </td>
						<td><?php echo $row->descripcion;?> </td>
						
						
	                   </tr>
							                 <?php
							$indice++;
											}
						?>


				</tbody>
				
			
			</table>
		</div>
	</div>
</div>


	
		<footer>
			<div class="w3-agileits-footer-top">
				<div class="container">
					<div class="wthree-foo-grids">
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Quienes somos</h4>
							<p>Para la solución al problema realizaremos una página web donde la gente pueda ofrecer sus productos y servicios y así poder llegar a mucha gente desde la comodidad de sus hogares, pensamos en eso ya que la mayoría de gente sin estudios superiores optan por el comercio de productos o servicios y así poder ganar dinero</p>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Ayuda</h4>
							<ul>
								<li><a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Como Funciona </a></li>						
								
								<li><a href="<?php echo base_url(); ?>index.php/usuario/productosno"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Productos no Validos</a></li>
								
								
								
							</ul>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Informacion</h4>
							<ul>
									
								<li><a href="<?php echo base_url(); ?>index.php/usuario/condicion"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Condiciones de Uso</a></li>

								
									<li><h3>Contactanos</h3>
	<a href="https://mail.google.com/mail/u/0/#inbox?compose=CllgCJlHmqfghfsRTTVqwdNsSlNJqjMvftfsFMfnpdWQhfvmrFdtrCqkWGnCNcnZrMhWTjxjTML">carrito0918@gmail.com</a></li>
								

								
							</ul>
						</div>
						
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="agileits-footer-bottom text-center">
			<div class="container">
				<div class="logo">
					<h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><span>Ebisu</span>-SAFE SALE FROM HOME</a></h1> 
				</div>
				<div class="copyrights">
					<p> © 2020. Creado por Team Ebisu |   <a href="<?php echo base_url(); ?>public/web/http://w3layouts.com/"> Cochabamba - Bolivia </a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->
		<!-- Navigation-Js-->
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/main.js"></script>
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/classie.js"></script>
		<!-- //Navigation-Js-->
		<!-- js -->
		<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.min.js"></script>
		<!-- js -->
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="<?php echo base_url(); ?>public/web/js/bootstrap.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/bootstrap-select.js"></script>
		<script>
		  $(document).ready(function () {
			var mySelect = $('#first-disabled2');

			$('#special').on('click', function () {
			  mySelect.find('option:selected').prop('disabled', true);
			  mySelect.selectpicker('refresh');
			});

			$('#special2').on('click', function () {
			  mySelect.find('option:disabled').prop('disabled', false);
			  mySelect.selectpicker('refresh');
			});

			$('#basic2').selectpicker({
			  liveSearch: true,
			  maxOptions: 1
			});
		  });
		</script>
		<!-- language-select -->
		<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.leanModal.min.js"></script>
		<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.grid.css" rel="stylesheet"/>
		<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.lcd.css" rel="stylesheet"/>
		<!-- Source -->
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.utils.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.lcd.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.languagefilter.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.regionfilter.js"></script>
		<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.core.js"></script>
		<script>
					$( document ).ready( function() {
						$( '.uls-trigger' ).uls( {
							onSelect : function( language ) {
								var languageName = $.uls.data.getAutonym( language );
								$( '.uls-trigger' ).text( languageName );
							},
							quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
						} );
					} );
				</script>
		<!-- //language-select -->
		<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.flexisel.js"></script><!-- flexisel-js -->	
					<script type="text/javascript">
						 $(window).load(function() {
							$("#flexiselDemo3").flexisel({
								visibleItems:1,
								animationSpeed: 1000,
								autoPlay: true,
								autoPlaySpeed: 5000,    		
								pauseOnHover: true,
								enableResponsiveBreakpoints: true,
								responsiveBreakpoints: { 
									portrait: { 
										changePoint:480,
										visibleItems:1
									}, 
									landscape: { 
										changePoint:640,
										visibleItems:1
									},
									tablet: { 
										changePoint:768,
										visibleItems:1
									}
								}
							});
							
						});
					   </script>
		<!-- Slider-JavaScript -->
			<script src="<?php echo base_url(); ?>public/web/js/responsiveslides.min.js"></script>	
			 <script>
			$(function () {	
			  $("#slider").responsiveSlides({
				auto: true,
				pager: false,
				nav: true,
				speed: 500,
				maxwidth: 800,
				namespace: "large-btns"
			  });

			});
		  </script>
		<!-- //Slider-JavaScript -->
		<!-- here stars scrolling icon -->
			<script type="text/javascript">
				$(document).ready(function() {
					/*
						var defaults = {
						containerID: 'toTop', // fading element id
						containerHoverID: 'toTopHover', // fading element hover id
						scrollSpeed: 1200,
						easingType: 'linear' 
						};
					*/
										
					$().UItoTop({ easingType: 'easeOutQuart' });
										
					});
			</script>
			<!-- start-smoth-scrolling -->
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/move-top.js"></script>
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
			</script>
			<!-- start-smoth-scrolling -->
		<!-- //here ends scrolling icon -->
</body>		
</html>