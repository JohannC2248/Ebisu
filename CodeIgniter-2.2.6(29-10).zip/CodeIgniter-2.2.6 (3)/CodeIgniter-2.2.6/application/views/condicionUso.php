<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title>Resale_v2 a Classified ads Category Flat Bootstrap Responsive Website Template | Como Funciona:: w3layouts</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="<?php echo base_url(); ?>public/web/css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
<!-- js -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url(); ?>public/web/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/bootstrap-select.js"></script>
<script>
  $(document).ready(function () {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker({
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<!-- language-select -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.leanModal.min.js"></script>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.utils.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.lcd.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.languagefilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.regionfilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.core.js"></script>
<script>
			$( document ).ready( function() {
				$( '.uls-trigger' ).uls( {
					onSelect : function( language ) {
						var languageName = $.uls.data.getAutonym( language );
						$( '.uls-trigger' ).text( languageName );
					},
					quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
				} );
			} );
		</script>
<!-- //language-select -->
</head>
<body>
	<!-- Navigation -->
		
		<!-- //Navigation -->
	<!-- header -->
	<header>
		<div class="w3ls-header"><!--header-one--> 
			
			<div class="w3ls-header-right">
				<ul>
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>public/web/signin.html" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i> Registrarse</a>
					</li>
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>public/web/help.html"><i class="fa fa-question-circle" aria-hidden="true"></i> Ayuda</a>
					</li>
					
					<li class="dropdown head-dpdn">
						<div class="header-right">			
	<!-- Large modal -->
			
		</div>
					</li>
				</ul>
			</div>
			
			<div class="clearfix"> </div> 
		</div>
		
	</header>
	<!-- //header -->
	<!-- breadcrumbs -->
	<div class="w3layouts-breadcrumbs text-center">
		<div class="container">
			<span class="agile-breadcrumbs"><a href="<?php echo base_url(); ?>public/web/index.html"><i class="fa fa-home home_1"></i></a> / <span>Condiciones de Uso</span></span>
		</div>
	</div>
	<!-- //breadcrumbs -->
	<!-- How it works -->
		<div class="work-section">
			<div class="container">
				<h2 class="w3-head"></h2>

					<div class="terms main-grid-border">
		<div class="container">
			<h2 class="w3-head">Condiciones de uso</h2>
				<div class="panel-group" id="accordion">
				<!-- First Panel -->
					<div class="panel panel-default">
						<div id="collapseOne" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Al utilizar los Servicios de esta pagina, usted acepta estas condiciones. Léalas detenidamente.
Ofrecemos una amplia gama de Servicios de esta pagina y, en algunas ocasiones, es posible que se agreguen otros términos.
</p>
								
							</div>
						</div>
						<div class="panel-heading">
							 <h4 class="panel-title" data-toggle="collapse" data-target="#collapseOne">
								 <span>1.</span> COPYRIGHT
							 </h4>
						</div>
						<div id="collapseOne" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Todo el contenido incluido o disponible a través de cualquier Servicio de esta pagina, como texto, gráficos, logotipos, iconos de botones, imágenes, clips de audio, descargas digitales, compilaciones de datos y software, es de propiedad de esta pagina o de sus proveedores de contenido y está protegido por las leyes estadounidenses e internacionales de copyright. La totalidad del contenido incluido o disponible a través de cualquier Servicio de esta pagina es de propiedad exclusiva de Amazon y está protegido por las leyes estadounidenses e internacionales de copyright.</p>
								
							</div>
						</div>
					</div>
					
					<!-- Second Panel -->
					<div class="panel panel-default">
						<div class="panel-heading">
							 <h4 class="panel-title" data-toggle="collapse"  data-target="#collapseTwo">
								<span>2.</span> OPINIONES, COMENTARIOS, COMUNICACIONES Y OTRO CONTENIDO
							 </h4>
						</div>
						<div id="collapseTwo" class="panel-collapse collapse">
							<div class="panel-body">								
								<p>Puede publicar comentarios, opiniones, fotos y enviar sugerencias, ideas, comentarios, preguntas u otra información, siempre que el contenido no sea ilegal, obsceno, amenazante, difamatorio o invasivo de la privacidad ni infrinja los derechos de propiedad intelectual (incluidos los derechos de publicidad) o resulte ofensivo para terceros u objetable de algún otro modo, y que no emplee ni contenga virus informáticos, propaganda política, incitación comercial, cadenas de mensajes, correos masivos o cualquier forma de correo no deseado o mensajes electrónicos comerciales no solicitados. No puede utilizar direcciones de correo electrónico falsas, ni suplantar a ninguna persona o entidad o de otra manera inducir al error en cuanto al origen de una tarjeta o de cualquier contenido. Esta pagina no revisa el contenido publicado de manera regular, pero se reserva el derecho (no la obligación) de eliminar o editar este contenido.</p>
								<p>Si publica contenido o envía material, y a no ser que indiquemos lo contrario, le otorga a esta pagina el derecho no exclusivo, gratuito, perpetuo, irrevocable y con sublicencia total a utilizar, reproducir, modificar, adaptar, publicar, ejecutar, traducir, crear trabajos derivados, distribuir y exhibir dicho contenido en todo el mundo y a través de cualquier medio. Usted otorga a esta pagina y sus sublicenciatarios el derecho a utilizar el nombre que usted presentó en relación con este contenido, en caso de que así lo elijan. Usted declara y garantiza que los derechos del contenido que publicó le pertenecen o están a su cargo; que el contenido es exacto; que la utilización del contenido no supondrá incumplimiento alguno de esta política y no supondrá perjuicio alguno para ninguna persona o entidad; y que usted indemnizará a esta pagina por cualquier reclamo que resulte del contenido que proporciona. Amazon tiene el derecho, pero no la obligación, de vigilar y editar o eliminar cualquier actividad o contenido. Amazon no asume responsabilidad alguna con respecto al contenido publicado por usted o cualquier tercero.
</p>
							</div>
						</div>
					</div>
					
					<!-- Third Panel -->
					<div class="panel panel-default">
						<div class="panel-heading">
							 <h4 class="panel-title" data-toggle="collapse" data-target="#collapseThree">
								<span>3.</span>RIESGO DE PÉRDIDA
							 </h4>
						</div>
						<div id="collapseThree" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Todas las compras de productos físicos de esta pagina se realizan de conformidad con un contrato de envío. Esto significa que el riesgo de pérdida y la titularidad de esos productos pasan a ser suyos desde el momento en que los entregamos al transportista.</p>
							</div>
						</div>
					</div>
					<!-- Fourth Panel -->
					<div class="panel panel-default">
						<div class="panel-heading">
							 <h4 class="panel-title" data-toggle="collapse" data-target="#collapseFour">
								<span>4.</span> DESCRIPCIONES DE LOS PRODUCTOS
							 </h4>
						</div>
						<div id="collapseFour" class="panel-collapse collapse">
							<div class="panel-body">
								<p>Esta pagina intenta ser lo más precisa posible. Sin embargo, Amazon no garantiza que las descripciones de los productos o el contenido de cualquier otro Servicio de Amazon sean precisos, completos y fiables, ni que estén actualizados o libres de errores. Si un producto ofrecido por Amazon no cumple con la descripción, la única solución será devolver el producto sin usar.</p>
							</div>
						</div>
					</div>
					<!-- Fifth Panel -->
					<div class="panel panel-default">
						<div class="panel-heading">
							 <h4 class="panel-title" data-toggle="collapse" data-target="#collapseFive">
								<span>5.</span> PRECIOS
							 </h4>
						</div>
						<div id="collapseFive" class="panel-collapse collapse">
							<div class="panel-body">
								<p>El "Precio de lista" se refiere al precio minorista sugerido de un producto tal como fue proporcionado por un fabricante, proveedor o vendedor. Contrastamos periódicamente los precios de lista con los precios encontrados recientemente en esta pagina y otras tiendas. Algunos productos pueden mostrar un "Precio anterior", que se determina usando el historial reciente de precios del producto en esta pagina.</p>
								<p>Con respecto a los productos vendidos por esta pagina, no podemos confirmar el precio de un producto antes de que haga su pedido. A pesar de hacer nuestro máximo esfuerzo por evitarlo, una pequeña parte de los productos de nuestro catálogo pueden tener precios incorrectos. Si el precio correcto de un producto vendido por esta pagina es más alto que el que figura en la página, a nuestra discreción, nos pondremos en contacto con usted antes de enviarle el producto o cancelaremos el pedido y le notificaremos acerca de la cancelación. Otros vendedores pueden tener políticas diferentes acerca de los productos con precios incorrectos.</p>
								<p>Generalmente, no hacemos el cobro en su tarjeta de crédito hasta después de que su pedido haya ingresado al proceso de envío o, en el caso de productos digitales, hasta que el producto digital esté disponible.</p>
								
							</div>
						</div>
					</div>
					
					
				</div>
		</div>	
	</div>
				<div class="clearfix"></div>
						
			</div>
		</div>
		</div>	
		
	<!-- // How it works -->
	<!--footer section start-->		
		<footer>
			
			<div class="agileits-footer-bottom text-center">
			<div class="container">
				<div class="logo">
					<h1><a href="<?php echo base_url(); ?>index.php/usuario"><span>Ebisu</span>-SAFE SALE FROM HOME</a></h1> 
				</div>
				<div class="copyrights">
					<p> © 2020. Creado por Team Ebisu |   <a href="<?php echo base_url(); ?>public/web/<?php echo base_url(); ?>public/web/http://w3layouts.com/"> Cochabamba - Bolivia </a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->
		<!-- Navigation-JavaScript -->
			<script src="<?php echo base_url(); ?>public/web/js/classie.js"></script>
			<script src="<?php echo base_url(); ?>public/web/js/main.js"></script>
		<!-- //Navigation-JavaScript -->
		<!-- here stars scrolling icon -->
			<script type="text/javascript">
				$(document).ready(function() {
					/*
						var defaults = {
						containerID: 'toTop', // fading element id
						containerHoverID: 'toTopHover', // fading element hover id
						scrollSpeed: 1200,
						easingType: 'linear' 
						};
					*/
										
					$().UItoTop({ easingType: 'easeOutQuart' });
										
					});
			</script>
			<!-- start-smoth-scrolling -->
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/move-top.js"></script>
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
			</script>
			<!-- start-smoth-scrolling -->
		<!-- //here ends scrolling icon -->
</body>
</html>