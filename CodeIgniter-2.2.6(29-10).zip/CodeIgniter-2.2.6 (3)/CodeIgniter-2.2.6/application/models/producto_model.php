<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Producto_model extends CI_Model {


	public function listarproducto()
	{
		
		$this->db->select('*');
		$this->db->from('producto');
		$this->db->where('estado',$estado=1);
		return $this->db->get();
	}
	public function listarproductouno()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=1);
		return $this->db->get();
	}
	public function listarproductodos()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=2);
		return $this->db->get();
	}

	public function listarproductotres()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=3);
		return $this->db->get();
	}

	public function listarproductocuatro()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=4);
		return $this->db->get();
	}

	public function listarproductocinco()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=5);
		return $this->db->get();
	}

	public function listarproductoseis()
	{
		$this->db->SELECT('*') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=6);
		return $this->db->get();
	}
	public function listarproductosiete()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=7);
		return $this->db->get();
	}
	public function listarproductoocho()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=8);
		return $this->db->get();
	}
	public function listarproductonueve()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=9);
		return $this->db->get();
	}
	public function listarproductodiez()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=10);
		return $this->db->get();
	}
	public function listarproductoonce()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=11);
		return $this->db->get();
	}
	public function listarproductodoce()
	{
		$this->db->SELECT('nombre , preciobase , categoria') ;
		$this->db->from('producto');
		$this->db->where('categoria',$categoria=12);
		return $this->db->get();
	}
	
	public function recuperarproducto($IdProducto)
	{
		$this->db->select('*');
		$this->db->from('producto');
		$this->db->where('IdProducto',$IdProducto);
        return $this->db->get();
	}
	public function modificarproducto($IdProducto,$data)

	{
		$this->db->where('IdProducto',$IdProducto);
		$this->db->update('producto',$data);
	}
	public function comprarproducto($IdProducto,$data)

	{
		$this->db->where('IdProducto',$IdProducto);
		$this->db->update('producto',$data);
	}
	public function agregarproducto($data)

	{
		
		$this->db->insert('producto',$data);
	}
	public function registrarproducto($pro)
	{
		
		$this->db->insert('registroproducto',$pro);
	}
	public function activarproducto($IdProducto)
	{
		
		$this->db->set('estado',$estado=0);
		$this->db->where('IdProducto',$IdProducto);
		$this->db->update('producto');
	}
	public function lista($pro)
	{
		
		$this->db->insert('lista',$pro);
	}
	
	

	

	


	
	
}

