<title>Resale_v2 a Classified ads Category Flat Bootstrap Responsive Website Template | Sign in :: w3layouts</title>
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="<?php echo base_url(); ?>public/web/css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts--> 
<!-- js -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url(); ?>public/web/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/bootstrap-select.js"></script>
<script>
  $(document).ready(function () {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker({
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<!-- language-select -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.leanModal.min.js"></script>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.utils.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.lcd.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.languagefilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.regionfilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.core.js"></script>
<script>
         $( document ).ready( function() {
            $( '.uls-trigger' ).uls( {
               onSelect : function( language ) {
                  var languageName = $.uls.data.getAutonym( language );
                  $( '.uls-trigger' ).text( languageName );
               },
               quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
            } );
         } );
      </script>
<!-- //language-select -->
</head>
<body>
   <!-- Navigation -->
      <div class="agiletopbar">
         <div class="wthreenavigation">
            <div class="menu-wrap">
            <nav class="menu">
               <div class="icon-list">
                  <a href="<?php echo base_url(); ?>/index.php/usuario/listaproducto"><i class="fa fa-fw fa-mobile"></i><span>LISTA PRODUCTOS</span></a>
                  <a href="<?php echo base_url(); ?>/index.php/usuario/listausurio"><i class="fa fa-fw fa-laptop"></i><span>LISTA USUARIOS</span></a>
                  
               </div>
            </nav>
            <button class="close-button" id="close-button">Close Menu</button>
         </div>
         <button class="menu-button" id="open-button"> </button>
         </div>
         <div class="clearfix"></div>
      </div>

      <!-- //Navigation -->
   <!-- header -->
   <header>
      <div class="w3ls-header"><!--header-one--> 
         
         <div class="w3ls-header-right">
            <ul>
               <li class="dropdown head-dpdn">
                  <a href="<?php echo base_url(); ?>/index.php/usuario/agregar" 
                     aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i> Sign In</a>
               </li>
               <li class="dropdown head-dpdn">
                  <a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-question-circle" aria-hidden="true"></i> Help</a>
               </li>
               
               <li class="dropdown head-dpdn">
                  <div class="header-right">       
   <!-- Large modal -->
         <div class="agile-its-selectregion">
            <button class="btn btn-primary" data-toggle="modal" data-target="#myModal">
            <i class="fa fa-globe" aria-hidden="true"></i>Select City</button>
               <div class="modal fade" id="myModal" tabindex="-1" role="dialog"
               aria-hidden="true">
                  <div class="modal-dialog modal-lg">
                     <div class="modal-content">
                        <div class="modal-header">
                           <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                              &times;</button>
                           <h4 class="modal-title" id="myModalLabel">
                              Please Choose Your Location</h4>
                        </div>
                        <div class="modal-body">
                            <form class="form-horizontal" action="#" method="get">
                              <div class="form-group">
                                 <select id="basic2" class="show-tick form-control" multiple>
                                    <optgroup label="Popular Cities">
                                       <option selected style="display:none;color:#eee;">Select City</option>
                                       <option>Birmingham</option>
                                       <option>Anchorage</option>
                                       <option>Phoenix</option>
                                       <option>Little Rock</option>
                                       <option>Los Angeles</option>
                                       
                                    </optgroup>
                                       
                                       
                                 </select>
                              </div>
                             </form>    
                        </div>
                     </div>
                  </div>
               </div>
         </div>
      </div>
               </li>
            </ul>
         </div>
         
         <div class="clearfix"> </div> 
      </div>
      <div class="container">
         <div class="agile-its-header">
            <div class="logo">
               <a href="<?php echo base_url(); ?>index.php/usuario"><span>Ebisu</span>-SAFE SALE FROM HOMEE</a></h1>
            </div>
            <div class="agileits_search">
               <form action="#" method="post">
                  <input name="Search" type="text" placeholder="How can we help you today?" required=" ">
                  <select id="agileinfo_search" name="agileinfo_search" required="">
                     <option value="">Todas las categorias</option>
                     <option value="Mobiles">Celulares</option>
                     <option value="Electronics & Appliances">Electronicos y accesorios</option>
                     <option value="Cars">Autos</option>
                     <option value="Bikes">Bicicletas</option>
                     <option value="Furnitures">Muebles</option>
                     <option value="Books, Sports & Hobbies">Libros, deportes y aficiones</option>
                     <option value="Fashion">Moda</option>
                     <option value="Kids">Niños</option>
                     <option value="Services">Servicios</option>
                     <option value="Jobs">Trabajos</option>
                     <option value="Real Estates">Bienes raices</option>
                  </select>
                  <button type="submit" class="btn btn-default" aria-label="Left Align">
                     <i class="fa fa-search" aria-hidden="true"> </i>
                  </button>
               </form>
            <a class="post-w3layouts-ad" href="<?php echo base_url();?>index.php/usuario/agregarproducto">Post Free Ad</a>
            </div>   
            <div class="clearfix"></div>
         </div>
      </div>
   </header>
   <!-- //header -->
   <!-- sign in form -->
    <section>

      <div id="agileits-sign-in-page" class="sign-in-wrapper" >
         
         <p class="text-center mb-lg">
               <br>
               
            </p>
         <div class="agileinfo_signin" >
            <p class="text-center mb-lg">
               <br>
               <a href="<?php echo base_url(); ?>public/web/#">
                  <img src="<?php echo base_url(); ?>public/web/images/logo3.png" alt="Image" class="block-center img-rounded" width="250">
               </a>
            </p>
         <div class="contanier">

   <section>
         <!-- START Page content-->
         <section class="main-content">
            <h3>MODIFICARR USUARIO
            </h3>
            <div class="contanier">
   <div class="contanier">
   <div class="row">
      <div class=" col-md-12">
         



         <?php

         

         foreach ($infousuario->result() as $row) {
         
         $atributos=array('class'=>'form-horizontal','role'=>'form','id'=>'miForm');
         
         echo form_open_multipart('usuario/modificardb',$atributos);
         ?> 

            <input type="hidden" name="IdUsuario" value="<?php echo $row->IdUsuario; ?>">
            <label class="text-center mb-lg">Nombre del Usuario:</label>
            <input type="text" name="nombre" value="<?php echo $row->nombre; ?>">
            <label class="text-center mb-lg">Primer Apellido:</label>
            <input type="text" name="primerApellido" value="<?php echo $row->primerApellido; ?>">
            <label class="text-center mb-lg">Segundo Apellido:</label>
            <input type="text" name="segundoApellido" value="<?php echo $row->segundoApellido; ?>"><label class="text-center mb-lg">Correo:</label>
            <input type="text" name="correo" value="<?php echo $row->correo; ?>">
            <label class="text-center mb-lg">Password:</label>
            <input type="password" name="password" value="<?php echo $row->password; ?>"><br><br>
            <label class="text-center mb-lg">Telefono:</label>
            <input type="number" name="telefono"  value="<?php echo $row->telefono; ?>"><br><br>
            
            Fecha Modificacion: <input type="date" name="fechaModificacion" step="1" min="2020-09-16" max="2020-09-30" value="<?php echo date("Y-m-d");?>"><br><br>
            <button type="submit" class="bt btn-info">MODIFICAR</button>
         <?php echo form_close();
         }
          ?>
                  
      </div>
   </div>
</div>
</div>

</div>



         </div>
      </div>
   </section>
   <!-- //sign in form -->
   <!--footer section start-->      
     <footer>
         <div class="w3-agileits-footer-top">
            <div class="container">
               <div class="wthree-foo-grids">
                  <div class="col-md-3 wthree-footer-grid">
                     <h4 class="footer-head">Who We Are</h4>
                     <p>Para la solución al problema realizaremos una página web donde la gente pueda ofrecer sus productos y servicios y así poder llegar a mucha gente desde la comodidad de sus hogares, pensamos en eso ya que la mayoría de gente sin estudios superiores optan por el comercio de productos o servicios y así poder ganar dinero</p>
                  </div>
                  <div class="col-md-3 wthree-footer-grid">
                     <h4 class="footer-head">Ayuda</h4>
                     <ul>
                        <li><a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Como Funciona </a></li>                
                        
                        <li><a href="<?php echo base_url(); ?>index.php/usuario/productosno"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Productos no Validos</a></li>
                        
                        
                        
                     </ul>
                  </div>
                  <div class="col-md-3 wthree-footer-grid">
                     <h4 class="footer-head">Information</h4>
                     <ul>
                           
                        <li><a href="<?php echo base_url(); ?>index.php/usuario/condicion"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Condiciones de Uso</a></li>
                        
                     </ul>
                  </div>
                  
                  <div class="clearfix"></div>
               </div>                  
            </div>   
         </div>   
         <div class="agileits-footer-bottom text-center">
         <div class="container">
            <div class="logo">
               <h1><a href="<?php echo base_url(); ?>index.php/usuario"><span>Ebisu</span>-SAFE SALE FROM HOME</a></h1> 
            </div>
            <div class="copyrights">
               <p> © 2020. Creado por Team Ebisu |   <a href="<?php echo base_url(); ?>public/web/http://w3layouts.com/"> Cochabamba - Bolivia </a></p>
            </div>
            <div class="clearfix"></div>
         </div>
      </div>
      </footer>
        <!--footer section end-->
</body>
      <!-- Navigation-JavaScript -->
         <script src="<?php echo base_url(); ?>public/web/js/classie.js"></script>
         <script src="<?php echo base_url(); ?>public/web/js/main.js"></script>
      <!-- //Navigation-JavaScript -->
      <!-- here stars scrolling icon -->
         <script type="text/javascript">
            $(document).ready(function() {
               /*
                  var defaults = {
                  containerID: 'toTop', // fading element id
                  containerHoverID: 'toTopHover', // fading element hover id
                  scrollSpeed: 1200,
                  easingType: 'linear' 
                  };
               */
                              
               $().UItoTop({ easingType: 'easeOutQuart' });
                              
               });
         </script>
         <!-- start-smoth-scrolling -->
         <script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/move-top.js"></script>
         <script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/easing.js"></script>
         <script type="text/javascript">
            jQuery(document).ready(function($) {
               $(".scroll").click(function(event){    
                  event.preventDefault();
                  $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
               });
            });
         </script>
         <!-- start-smoth-scrolling -->
      <!-- //here ends scrolling icon -->
</html>


