<!DOCTYPE html>
<html lang="en">
<head>
<title>Ebisu SAFE SALE FROM HOME </title><link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="<?php echo base_url(); ?>public/web/css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<!--//fonts-->	
<!-- js -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.min.js"></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url(); ?>public/web/js/bootstrap.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/bootstrap-select.js"></script>
<script>
  $(document).ready(function () {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker({
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<!-- language-select -->
<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/jquery.leanModal.min.js"></script>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.grid.css" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>public/web/css/jquery.uls.lcd.css" rel="stylesheet"/>
<!-- Source -->
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.data.utils.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.lcd.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.languagefilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.regionfilter.js"></script>
<script src="<?php echo base_url(); ?>public/web/js/jquery.uls.core.js"></script>
<script>
			$( document ).ready( function() {
				$( '.uls-trigger' ).uls( {
					onSelect : function( language ) {
						var languageName = $.uls.data.getAutonym( language );
						$( '.uls-trigger' ).text( languageName );
					},
					quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
				} );
			} );
		</script>
<!-- //language-select -->
<!-- responsive tabs -->
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>public/web/css/easy-responsive-tabs.css " />
    <script src="<?php echo base_url(); ?>public/web/js/easyResponsiveTabs.js"></script>
<!-- /responsive tabs -->
</head>
<body>
	<header>
		<div class="w3ls-header"><!--header-one--> 
			
			<div class="w3ls-header-right">
				<ul>

					<li class="dropdown head-dpdn">
						<h1><a href="" aria-expanded="false"><i aria-hidden="true">HOLA  <?php echo $this->session->userdata('nombre'); ?></a></h1> 
						
					</li>
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>index.php/usuario/logout" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i>CERRAR SESSION</a>
					</li>
					
			
					
					<li class="dropdown head-dpdn">
						<a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-question-circle" aria-hidden="true"></i> Ayuda</a>
					</li>
					
					
				</ul>
			</div>
			
			<div class="clearfix"> 
				<ul>
					<li>
					
    
 		   
					</li>
				</ul>
			</div> 
		</div>
		<div class="container">
			<div class="agile-its-header">
				<div class="logo">
					
					<h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><img src="<?php echo base_url(); ?>public/web/images/logo3.png" alt="Image" class="block-center img-rounded" width="150"><span>Ebisu</span>-SAFE SALE FROM HOME </a> </h1>

				</div>
				<div class="agileits_search">
					
				<a  class="post-w3layouts-ad btn btn-purple" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodos">Nuestro Producto</a>
				

				<a class="post-w3layouts-ad" href="<?php echo base_url(); ?>/index.php/usuario/agregarproducto">Registrar Producto</a>
				</div>	
				<div class="clearfix"></div>
			</div>
		</div>
	</header>
	<div class="w3layouts-breadcrumbs text-center">
		<div class="container">
			<span class="agile-breadcrumbs"><a href="<?php echo base_url(); ?>public/web/index.html"><i class="fa fa-home home_1"></i></a> / <span>Categorias</span></span>
		</div>
	</div>
	<!-- //breadcrumbs -->
	<!-- Categories -->
	<!--Vertical Tab-->
	<div class="categories-section main-grid-border">
		<div class="container">
			<h2 class="w3-head">All Categorias</h2>
			<div class="category-list">
				<div id="parentVerticalTab">
					<div class="agileits-tab_nav">
					<ul class="resp-tabs-list hor_1">
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductouno#parentVerticalTab2">CASA Y JARDIN</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductodos#parentVerticalTab2">ROPA Y ACCESORIOS</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductotres#parentVerticalTab3">ELECTRONICOS</a> </li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductocuatro#parentVerticalTab4">BICICLETAS</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductocinco#parentVerticalTab5">JUGUETES</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductoseis#parentVerticalTab6">CLASIFICADOS</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductosiete#parentVerticalTab7">LIBROS PASAPORTES Y DEPORTES</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductoocho#parentVerticalTab8">INSTRUMENTOS</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductonueve#parentVerticalTab9">ENTRETENIMINETO</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductodiez#parentVerticalTab10">SERVICIOS</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductoonce#parentVerticalTab11">TRABAJO</a></li>
						<li><a  href="<?php echo base_url(); ?>/index.php/usuario/listaproductodoce#parentVerticalTab12">MUEBLES</a></li>
					</ul>
						
					</div>

					
			<div class="resp-tabs-container hor_6">
										
						<div>
							<div class="category">
								<?php
								$indice=1;
								foreach ($producto->result() as $row)
								{
									?> 
								<div class="category-img">
									<img src="<?php echo base_url(); ?>public/web/images/p-5.png" title="image" alt="" />
								</div>
								<div class="category-info">
									<h4>Nombre</h4>
									<span><?php echo $row->nombre;?></span>
									<div class="wishlist">
                                    <?php echo form_open_multipart('usuario/listadeseos');?>
                					
                					<input type="hidden" name="idProducto" value="<?php echo $row->IdProducto; ?>">
                					<input type="hidden" name="codigo" value="<?php echo $row->codigo; ?>">
                					<input type="hidden" name="fechaCreacion" value="<?php echo $row->fechaCreacion; ?>">
                					<input type="hidden" name="precioBase" value="<?php echo $row->precioBase; ?>">
                					<input type="hidden" name="nombre" value="<?php echo $row->nombre; ?>">
									<button type="submit" class="bt btn-danger"><i class="fa fa-heart"></i>&nbsp;Añadir a Lista de deseos</button>
									<?php echo form_close(); ?> <br><br>
									<?php echo form_open_multipart('usuario/listadeseosver');?>
                					
                					<input type="hidden" name="idProducto" value="<?php echo $row->IdProducto; ?>">
                					<input type="hidden" name="codigo" value="<?php echo $row->codigo; ?>">
                					<input type="hidden" name="fechaCreacion" value="<?php echo $row->fechaCreacion; ?>">
                					<input type="hidden" name="precioBase" value="<?php echo $row->precioBase; ?>">
                					<input type="hidden" name="nombre" value="<?php echo $row->nombre; ?>">
									<button type="submit" class="bt btn-danger"><i class="fa fa-heart"></i>&nbsp;Ver mi lista deseos</button>
									<?php echo form_close(); ?> 
	                            	</div>

                				</div>
                				<div class="category-info">
									<h4>Precio</h4>
									<span><?php echo $row->precioBase;?></span>
									
									<?php echo form_open_multipart('usuario/compraproducto');?>
                					<input type="hidden" name="idProducto" value="<?php echo $row->IdProducto; ?>">
                					<button type="submit" class="bt btn-danger">Ver producto</button>
									<?php echo form_close(); ?>
		                		</div>
								<div class="clearfix"></div>
							</div>
					


							<div class="sub-categories">
								
				                 <?php
								$indice++;
								}
								?>
								
							</div>
						</div>
					</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
    $(document).ready(function() {

        //Vertical Tab
        $('#parentVerticalTab').easyResponsiveTabs({
            type: 'vertical', //Types: default, vertical, accordion
            width: 'auto', //auto or any width like 600px
            fit: true, // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            tabidentify: 'hor_1', // The tab groups identifier
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#nested-tabInfo2');
                var $name = $('span', $info);
                $name.text($tab.text());
                $info.show();
            }
        });
    });
</script>
	<!-- //Categories -->
	<!--footer section start-->		
		<footer>
			<div class="w3-agileits-footer-top">
				<div class="container">
					<div class="wthree-foo-grids">
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Quienes somos</h4>
							<p>Para la solución al problema realizaremos una página web donde la gente pueda ofrecer sus productos y servicios y así poder llegar a mucha gente desde la comodidad de sus hogares, pensamos en eso ya que la mayoría de gente sin estudios superiores optan por el comercio de productos o servicios y así poder ganar dinero</p>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Ayuda</h4>
							<ul>
								<li><a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Como Funciona </a></li>						
								
								<li><a href="<?php echo base_url(); ?>index.php/usuario/productosno"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Productos no Validos</a></li>
								
								
								
							</ul>
						</div>
						<div class="col-md-3 wthree-footer-grid">
							<h4 class="footer-head">Informacion</h4>
							<ul>
									
								<li><a href="<?php echo base_url(); ?>index.php/usuario/condicion"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Condiciones de Uso</a></li>
								
							</ul>
						</div>
						
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="agileits-footer-bottom text-center">
			<div class="container">
				<div class="logo">
					<h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><span>Ebisu</span>-SAFE SALE FROM HOME</a></h1> 
				</div>
				<div class="copyrights">
					<p> © 2020. Creado por Team Ebisu |   <a href="<?php echo base_url(); ?>public/web/http://w3layouts.com/"> Cochabamba - Bolivia </a></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->
		<!-- Navigation-JavaScript -->
			<script src="<?php echo base_url(); ?>public/web/js/classie.js"></script>
			<script src="<?php echo base_url(); ?>public/web/js/main.js"></script>
		<!-- //Navigation-JavaScript -->
		<!-- here stars scrolling icon -->
			<script type="text/javascript">
				$(document).ready(function() {
					/*
						var defaults = {
						containerID: 'toTop', // fading element id
						containerHoverID: 'toTopHover', // fading element hover id
						scrollSpeed: 1200,
						easingType: 'linear' 
						};
					*/
										
					$().UItoTop({ easingType: 'easeOutQuart' });
										
					});
			</script>
			<!-- start-smoth-scrolling -->
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/move-top.js"></script>
			<script type="text/javascript" src="<?php echo base_url(); ?>public/web/js/easing.js"></script>
			<script type="text/javascript">
				jQuery(document).ready(function($) {
					$(".scroll").click(function(event){		
						event.preventDefault();
						$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
					});
				});
			</script>
			<!-- start-smoth-scrolling -->
		<!-- //here ends scrolling icon -->
</body>
</html>