<!DOCTYPE html>
<!--[if lt IE 7]> <html class="ie ie6 lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="ie ie7 lt-ie9 lt-ie8"        lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="ie ie8 lt-ie9"               lang="en"> <![endif]-->
<!--[if IE 9]>    <html class="ie ie9"                      lang="en"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en" class="no-ie">
<!--<![endif]-->

<head>
   <!-- Meta-->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
   <meta name="description" content="">
   <meta name="keywords" content="">
   <meta name="author" content="">
   <title>47Admin - Bootstrap Admin Skin</title>
   <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
   <!--[if lt IE 9]><script src="<?php echo base_url(); ?>public/tabla/https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script><script src="<?php echo base_url(); ?>public/tabla/https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script><![endif]-->
   <!-- Bootstrap CSS-->
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/tabla/app/css/bootstrap.css">
   <!-- Vendor CSS-->
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/tabla/vendor/fontawesome/css/font-awesome.min.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/tabla/vendor/animo/animate+animo.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/tabla/vendor/csspinner/csspinner.min.css">
   <!-- START Page Custom CSS-->
   <!-- Data Table styles-->
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/tabla/vendor/datatable/extensions/datatable-bootstrap/css/dataTables.bootstrap.css">
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/tabla/vendor/datatable/extensions/ColVis/css/dataTables.colVis.css">
   <!-- END Page Custom CSS-->
   <!-- App CSS-->
   <link rel="stylesheet" href="<?php echo base_url(); ?>public/tabla/app/css/app.css">
   <!-- Modernizr JS Script-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/modernizr/modernizr.js" type="application/javascript"></script>
   <!-- FastClick for mobiles-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/fastclick/fastclick.js" type="application/javascript"></script>

   <link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css"><!-- bootstrap-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
<link href="<?php echo base_url(); ?>public/web/css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/flexslider.css" type="text/css" media="screen" /><!-- flexslider-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/font-awesome.min.css" /><!-- fontawesome-CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/menu_sideslide.css" type="text/css" media="all"><!-- Navigation-CSS -->
<!-- meta tags -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //meta tags -->
<!--fonts-->
<link rel="stylesheet" href="<?php echo base_url(); ?>public/web/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="<?php echo base_url(); ?>public/web/js/jquery-3.3.1.js"></script>

<!-- Popper JS -->
<script src="<?php echo base_url(); ?>public/web/js/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="<?php echo base_url(); ?>public/web/js/bootstrap.min.js"></script>
<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
</head>

<body>

   <header>
      <div class="w3ls-header"><!--header-one--> 
         
         <div class="w3ls-header-right">
            <ul>

               <li class="dropdown head-dpdn">
                  <h1><a href="" aria-expanded="false"><i aria-hidden="true">HOLA  <?php echo $this->session->userdata('nombre'); ?></a></h1> 
                  
               </li>
               <li class="dropdown head-dpdn">
                  <a href="<?php echo base_url(); ?>index.php/usuario/logout" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i>CERRAR SESSION</a>
               </li>
               
         
               
               <li class="dropdown head-dpdn">
                  <a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-question-circle" aria-hidden="true"></i> Ayuda</a>
               </li>
               
               
            </ul>
         </div>
         
         <div class="clearfix"> 
            <ul>
               <li>
               
    
         
               </li>
            </ul>
         </div> 
      </div>
      <div class="container">
         <div class="agile-its-header">
            <div class="logo">
               
               <h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><img src="<?php echo base_url(); ?>public/web/images/logo3.png" alt="Image" class="block-center img-rounded" width="150"><span>Ebisu</span>-SAFE SALE FROM HOME </a> </h1>

            </div>
            <div class="agileits_search">
               
            <a  class="post-w3layouts-ad btn btn-purple" href="<?php echo base_url(); ?>/index.php/usuario/listaproductodos">Nuestro Producto</a>
            

            <a class="post-w3layouts-ad" href="<?php echo base_url(); ?>/index.php/usuario/agregarproducto">Registrar Producto</a>
            </div>   
            <div class="clearfix"></div>
         </div>
      </div>
   </header>
   <!-- START Main wrapper-->
   <section class="wrapper">
     
      <section class="main-content">
            <h3>Tabla de Productos 
               <br>
               <small>Tablas de Productos por nombre, precioBase,stok categoria y codigo.</small>
            </h3>
                        <!-- START DATATABLE 2 -->
            <div class="row">
               <div class="col-lg-12">
                  <div class="panel panel-default">
                     <div class="panel-heading">Tabla de  productos para una mejor busqueda |
                        <small>Columnas Ordenadas</small>
                     </div>
                     <div class="panel-body">
                        
                        <table id="datatable2" class="table table-striped table-hover">
            <thead>
              
               <th>Nombre</th>
               <th>PrecioBase</th>
               <th>Stock</th>
               <th>Codigo</th>
               <th>imagens</th>
               <th>Descipcion</th>
               <th>Comprar</th>
               
            </thead>
            <tbody>
               <?php
               $indice=1;
               foreach ($producto->result() as $row)
               {
                  ?>
                  <tr >
                  
                  <td><?php echo $row->nombre;?> </td>
                  <td><?php echo $row->precioBase;?> </td>
                   <td><?php echo $row->stock;?> </td>
                  <td><?php echo $row->codigo;?> </td>
                  <td>
                        <img width="200px" src="img/<?php echo $row->ruta;?>">
                  </td>
                  <td><?php echo $row->descripcion;?> </td>
                  <td>

                     <?php echo form_open_multipart('usuario/modificarp');?>
                              <input type="hidden" name="IdProducto" value="<?php echo $row->IdProducto; ?>">
                              
                              <button type="submit" class="bt btn-danger">Ver producto</button>
                           <?php echo form_close(); ?>
                           
                  </td>
                  
                      </tr>
                    <?php
                     $indice++;
                                 }
                  ?>


            </tbody>
            <tfoot>
                                 <tr>
                                    <th>
                                       <input type="text" name="filter_browser" placeholder="Filtrar Nombre" class="form-control input-sm datatable_input_col_search">
                                    </th>
                                    <th>
                                       <input type="text" name="filter_browser" placeholder="Filtrar Nombre" class="form-control input-sm datatable_input_col_search">
                                    </th>
                                    <th>
                                       <input type="text" name="filter_platform" placeholder="Filtar Precio" class="form-control input-sm datatable_input_col_search">
                                    </th>
                                    <th>
                                       <input type="text" name="filter_engine_version" placeholder="Filtrar Categoria" class="form-control input-sm datatable_input_col_search">
                                    </th>
                                    <th>
                                       <input type="text" name="filter_css_grade" placeholder="Filtrar Stok" class="form-control input-sm datatable_input_col_search">
                                    </th>
                                    <th>
                                       <input type="text" name="filter_css_grade" placeholder="Filtrar codigo" class="form-control input-sm datatable_input_col_search">
                                    </th>
                                 </tr>
                              </tfoot>
            
         </table>
         
      </div>
   
</div>


                     </div>
                  </div>
               </div>
            </div>
            <!-- END DATATABLE 2 -->
            
         </section>
         <!-- END Page content-->
      </section>
      <!-- END Main section-->
   </section>
   <footer>
         <div class="w3-agileits-footer-top">
            <div class="container">
               <div class="wthree-foo-grids">
                  <div class="col-md-3 wthree-footer-grid">
                     <h4 class="footer-head">Quienes somos</h4>
                     <p>Para la solución al problema realizaremos una página web donde la gente pueda ofrecer sus productos y servicios y así poder llegar a mucha gente desde la comodidad de sus hogares, pensamos en eso ya que la mayoría de gente sin estudios superiores optan por el comercio de productos o servicios y así poder ganar dinero</p>
                  </div>
                  <div class="col-md-3 wthree-footer-grid">
                     <h4 class="footer-head">Ayuda</h4>
                     <ul>
                        <li><a href="<?php echo base_url(); ?>index.php/usuario/funciona"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Como Funciona </a></li>                
                        
                        <li><a href="<?php echo base_url(); ?>index.php/usuario/productosno"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Productos no Validos</a></li>
                        
                        
                        
                     </ul>
                  </div>
                  <div class="col-md-3 wthree-footer-grid">
                     <h4 class="footer-head">Informacion</h4>
                     <ul>
                           
                        <li><a href="<?php echo base_url(); ?>index.php/usuario/condicion"><i class="fa fa-long-arrow-right" aria-hidden="true"></i>Condiciones de Uso</a></li>
                        
                     </ul>
                  </div>
                  
                  <div class="clearfix"></div>
               </div>                  
            </div>   
         </div>   
         <div class="agileits-footer-bottom text-center">
         <div class="container">
            <div class="logo">
               <h1><a href="<?php echo base_url(); ?>index.php/usuario/panel"><img src="<?php echo base_url(); ?>public/web/images/logo3.png" alt="Image" class="block-center img-rounded" width="150"><span>Ebisu</span>-SAFE SALE FROM HOME </a> </h1>
            </div>
            <div class="copyrights">
               <p> © 2020. Creado por Team Ebisu |   <a href="<?php echo base_url(); ?>public/web/http://w3layouts.com/"> Cochabamba - Bolivia </a></p>
            </div>
            <div class="clearfix"></div>
         </div>
      </div>
      </footer>
   <!-- END Main wrapper-->
   <!-- START Scripts-->
   <!-- Main vendor Scripts-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/jquery/jquery.min.js"></script>
   <script src="<?php echo base_url(); ?>public/tabla/vendor/bootstrap/js/bootstrap.min.js"></script>
   <!-- Plugins-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/chosen/chosen.jquery.min.js"></script>
   <script src="<?php echo base_url(); ?>public/tabla/vendor/slider/js/bootstrap-slider.js"></script>
   <script src="<?php echo base_url(); ?>public/tabla/vendor/filestyle/bootstrap-filestyle.min.js"></script>
   <!-- Animo-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/animo/animo.min.js"></script>
   <!-- Sparklines-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/sparklines/jquery.sparkline.min.js"></script>
   <!-- Slimscroll-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/slimscroll/jquery.slimscroll.min.js"></script>
   <!-- START Page Custom Script-->
   <!-- Data Table Scripts-->
   <script src="<?php echo base_url(); ?>public/tabla/vendor/datatable/media/js/jquery.dataTables.min.js"></script>
   <script src="<?php echo base_url(); ?>public/tabla/vendor/datatable/extensions/datatable-bootstrap/js/dataTables.bootstrap.js"></script>
   <script src="<?php echo base_url(); ?>public/tabla/vendor/datatable/extensions/datatable-bootstrap/js/dataTables.bootstrapPagination.js"></script>
   <script src="<?php echo base_url(); ?>public/tabla/vendor/datatable/extensions/ColVis/js/dataTables.colVis.min.js"></script>
   <!-- END Page Custom Script-->
   <!-- App Main-->
   <script src="<?php echo base_url(); ?>public/tabla/app/js/app.js"></script>
   <!-- END Scripts-->
</body>

</html>